#!/usr/bin/env bash
# Usage: DATABASE_URL='postgres://...' bash deploy.sh
# Get DATABASE_URL from the Neon dashboard (Connection string, pooled).
set -euo pipefail
: "${DATABASE_URL:?Set DATABASE_URL first (Neon connection string)}"
SCOPE=qqq-f4b7
npx vercel login
npx vercel link --yes --scope "$SCOPE" --project pediatrics-paper2
for ENVN in production preview; do
  printf '%s' "$DATABASE_URL" | npx vercel env add DATABASE_URL "$ENVN" --scope "$SCOPE" --force || true
done
npm ci --no-audit --no-fund
node scripts/migrate.mjs   # creates tables only if missing (IF NOT EXISTS)
npx vercel deploy --prod --yes --scope "$SCOPE"
