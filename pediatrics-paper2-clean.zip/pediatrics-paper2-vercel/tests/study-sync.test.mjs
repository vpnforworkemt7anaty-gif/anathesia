import {test} from 'node:test';
import assert from 'node:assert/strict';
import {createStudySync,mergeEvents,newer,makeBatch,decodeLegacyResume} from '../public/study-sync.js';
import {MAX_QUESTION_ID,validateResume,validateEvents,legacyResume,withLegacyResume,realEvents} from '../lib/progress-model.ts';
class Storage {
 map=new Map();get length(){return this.map.size}key(i){return [...this.map.keys()][i]??null}getItem(k){return this.map.get(k)??null}setItem(k,v){this.map.set(k,String(v))}removeItem(k){this.map.delete(k)}
}
const settle=async()=>{for(let i=0;i<20;i++)await Promise.resolve()};
class Clock {
 time=1000000;id=0;timers=new Map();now=()=>this.time;
 set=(fn,delay)=>{const id=++this.id;this.timers.set(id,{at:this.time+delay,fn});return id};clear=id=>this.timers.delete(id);
 async tick(ms){const end=this.time+ms;let steps=0;for(;;){await settle();const next=[...this.timers].filter(([,t])=>t.at<=end).sort((a,b)=>a[1].at-b[1].at)[0];if(!next)break;assert.ok(++steps<10000,'timer loop');this.time=next[1].at;this.timers.delete(next[0]);next[1].fn();}this.time=end;await settle();}
}
const e=(v,t=100,d='A')=>({v,t,d});
const cfg={selected:['APGAR score'],typeChoice:['MCQ','SAQ','Show Answer'],sources:{},mode:'all',view:'single',auto:false,delay:450,review:false,index:1,hideDuplicates:true,search:'',cursorId:2,unansweredPendingId:null};
const resume=(t=100,d='A')=>({v:{config:{...cfg},cursors:{abc:2}},t,d});
function server(){
 const profiles=new Map(),calls=[];let writes=0;
 const row=p=>{if(!profiles.has(p))profiles.set(p,{events:{},resume:null,revision:0});return profiles.get(p)};
 const transport=p=>async req=>{
  calls.push({profile:p,...req});const r=row(p),etag='"'+p+'-'+r.revision+'"';
  if(req.method==='GET')return req.etag===etag?{notModified:true}:{...structuredClone(r),etag};
  const merged=mergeEvents(r.events,req.payload.events),res=newer(req.payload.resume,r.resume)?req.payload.resume:r.resume;
  if(JSON.stringify(merged)!==JSON.stringify(r.events)||res!==r.resume){writes++;r.revision++;r.events=merged;r.resume=res;}
  return {events:Object.fromEntries(Object.keys(req.payload.events).map(k=>[k,r.events[k]])),...(req.payload.resume?{resume:r.resume}:{}),revision:r.revision};
 };
 return {profiles,calls,row,transport,get writes(){return writes}};
}
function harness({s=server(),clock=new Clock(),storage=new Storage(),profile='MO',actor='A',transport,...extra}={}){
 let online=true,visible=true,cache={events:{}},states=[];
 const sync=createStudySync({storage,prefix:profile,actor,transport:transport||s.transport(profile),now:clock.now,setTimer:clock.set,clearTimer:clock.clear,random:()=>0.5,online:()=>online,visible:()=>visible,onRemote:r=>{cache.events=mergeEvents(cache.events,r.events);if(newer(r.resume,cache.resume))cache.resume=r.resume},onStatus:state=>states.push(state),...extra});
 return {sync,s,clock,storage,states,get cache(){return cache},set online(v){online=v},set visible(v){visible=v}};
}
test('one initial read, no idle/background traffic or writes for an hour',async()=>{
 const h=harness();await h.sync.start();assert.equal(h.s.calls.length,1);await h.clock.tick(3600000);assert.equal(h.s.calls.length,1);assert.equal(h.s.writes,0);h.visible=false;await h.sync.hide();await h.clock.tick(3600000);assert.equal(h.s.calls.length,1);
});
test('rapid changes coalesce; subsequent sends contain only new values',async()=>{
 const h=harness();await h.sync.start();h.sync.queue({events:{'pick:1':e(0)}});h.sync.queue({events:{'pick:2':e(1,101)}});h.sync.queue({events:{'pick:1':e(2,102)}});await h.clock.tick(1500);
 assert.deepEqual(Object.keys(h.s.calls.at(-1).payload.events).sort(),['pick:1','pick:2']);assert.equal(h.s.row('MO').events['pick:1'].v,2);assert.deepEqual(h.sync.pending().events,{});
 h.sync.queue({events:{'mark:1':e(true,103)}});await h.clock.tick(10000);assert.deepEqual(Object.keys(h.s.calls.at(-1).payload.events),['mark:1']);assert.equal(h.s.calls.filter(c=>c.method==='GET').length,1);
});
test('offline queue survives closing and reloading, including resume',async()=>{
 const storage=new Storage(),s=server();const a=harness({storage,s});await a.sync.start();a.online=false;a.sync.queue({events:{'pick:3':e(1)},resume:resume()});a.sync.stop();
 const b=harness({storage,s,actor:'B'});assert.equal(b.sync.pending().events['pick:3'].v,1);await b.sync.start();assert.equal(s.row('MO').events['pick:3'].v,1);assert.equal(s.row('MO').resume.v.config.cursorId,2);assert.deepEqual(b.sync.pending().events,{});
});
test('an edit during an in-flight request survives the older ACK',async()=>{
 const s=server();let release;const normal=s.transport('MO');const h=harness({s,transport:async req=>{const r=await normal(req);if(req.method==='POST')await new Promise(resolve=>release=resolve);return r;}});await h.sync.start();h.sync.queue({events:{'pick:1':e(0)}});const p=h.sync.flush();await settle();h.sync.queue({events:{'pick:1':e(2,101)}});release();await p;assert.equal(h.sync.pending().events['pick:1'].v,2);
});
test('two tabs never remove a newer edit while acknowledging an older one',async()=>{
 const storage=new Storage(),s=server();let release;const normal=s.transport('MO');const a=harness({storage,s,transport:async req=>{const r=await normal(req);if(req.method==='POST')await new Promise(resolve=>release=resolve);return r;}}),b=harness({storage,s,actor:'B'});await a.sync.start();await b.sync.start();a.sync.queue({events:{'pick:7':e(0)}});const p=a.sync.flush();await settle();b.sync.queue({events:{'pick:7':e(1,200,'B')}});release();await p;assert.equal(a.sync.pending().events['pick:7'].v,1);await b.sync.flush();assert.equal(s.row('MO').events['pick:7'].v,1);
});
test('three profiles isolate their queues and cloud progress',async()=>{
 const s=server(),storage=new Storage();for(const [i,p] of ['MO','Basant','Mada'].entries()){const h=harness({s,storage,profile:p});await h.sync.start();h.sync.queue({events:{'pick:1':e(i)}});await h.sync.flush();h.sync.stop();}assert.deepEqual(['MO','Basant','Mada'].map(p=>s.row(p).events['pick:1'].v),[0,1,2]);
});
test('two devices merge concurrent answers and resume; stale writes are ACKed',async()=>{
 const s=server(),a=harness({s}),b=harness({s,actor:'B'});await a.sync.start();await b.sync.start();a.sync.queue({events:{'pick:1':e(0,100)},resume:resume(100)});b.sync.queue({events:{'pick:2':e(1,200,'B')},resume:resume(200,'B')});await a.sync.flush();await b.sync.flush();await a.clock.tick(5001);await a.sync.wake();assert.deepEqual(Object.keys(a.cache.events).sort(),['pick:1','pick:2']);assert.equal(a.cache.resume.t,200);
 a.sync.queue({events:{'pick:2':e(0,50)}});await a.sync.flush();assert.deepEqual(a.sync.pending().events,{});assert.equal(a.cache.events['pick:2'].v,1);
});
test('POST does not advance the GET ETag past unseen remote changes',async()=>{
 const s=server(),a=harness({s}),b=harness({s,actor:'B'});await a.sync.start();await b.sync.start();b.sync.queue({events:{'pick:9':e(1)}});await b.sync.flush();a.sync.queue({events:{'pick:10':e(2)}});await a.sync.flush();await a.clock.tick(5001);await a.sync.wake();assert.equal(a.cache.events['pick:9'].v,1);
});
test('focus events coalesce and unchanged focus reads use conditional ETag',async()=>{
 const h=harness();await h.sync.start();h.sync.wake();h.sync.wake();assert.equal(h.s.calls.length,1);await h.clock.tick(6000);await Promise.all([h.sync.wake(),h.sync.wake(),h.sync.wake()]);assert.equal(h.s.calls.length,2);assert.ok(h.s.calls.at(-1).etag);assert.equal(h.s.writes,0);
});
test('failures back off, stop after five attempts and retain the outbox',async()=>{
 let posts=0;const s=server(),normal=s.transport('MO');const h=harness({s,transport:async req=>{if(req.method==='POST'){posts++;throw Error('offline server')}return normal(req)}});await h.sync.start();h.sync.queue({events:{'pick:1':e(0)}});await h.clock.tick(3600000);assert.equal(posts,5);assert.equal(h.sync.pending().events['pick:1'].v,0);assert.equal(h.states.at(-1),'waiting');await h.sync.wake();assert.equal(posts,6);
});
test('authentication failures pause automatic retries',async()=>{
 const s=server(),normal=s.transport('MO');let posts=0;const h=harness({s,transport:async req=>{if(req.method==='POST'){posts++;throw Object.assign(Error('session changed'),{status:401})}return normal(req)}});await h.sync.start();h.sync.queue({events:{'pick:1':e(1)}});await h.clock.tick(3600000);assert.equal(posts,1);assert.equal(h.states.at(-1),'signin');assert.ok(h.sync.pending().events['pick:1']);
});
test('hidden flush has a small keepalive body; hidden edits cause no retries',async()=>{
 const h=harness();await h.sync.start();for(let i=1;i<=600;i++)h.sync.queue({events:{['pick:'+i]:e(1,i)}});h.visible=false;await h.sync.hide();const post=h.s.calls.at(-1);assert.equal(post.keepalive,true);assert.ok(Buffer.byteLength(JSON.stringify(post.payload))<=28000);const n=h.s.calls.length;await h.clock.tick(3600000);assert.equal(h.s.calls.length,n);h.visible=true;await h.sync.wake();await h.clock.tick(100000);assert.equal(Object.keys(h.s.row('MO').events).length,600);
});
test('large histories are split into bounded deltas and fully acknowledged',async()=>{
 const h=harness();const events=Object.fromEntries(Array.from({length:1829},(_,i)=>['pick:'+(i+1),e(1,i,'device-with-a-longer-id')]));await h.sync.start({events,resume:resume()});await h.clock.tick(100000);assert.equal(Object.keys(h.s.row('MO').events).length,1829);assert.ok(h.s.calls.filter(c=>c.method==='POST').every(c=>Buffer.byteLength(JSON.stringify(c.payload))<=28000));assert.deepEqual(h.sync.pending().events,{});
});
test('legacy resume round-trips and is removed from question events',()=>{
 const r=validateResume(resume()),old=withLegacyResume({'pick:1':e(0)},r);assert.deepEqual(legacyResume(old),r);assert.deepEqual(decodeLegacyResume(old),r);assert.deepEqual(Object.keys(realEvents(old)),['pick:1']);assert.throws(()=>validateEvents(old));assert.equal(Object.keys(validateEvents(old,true)).length,Object.keys(old).length);assert.throws(()=>validateResume({...r,v:{...r.v,config:{...cfg,selected:'bad'}}}));
});
test('invalid IDs and future timestamps are rejected',()=>{
 assert.throws(()=>validateEvents({['pick:'+(MAX_QUESTION_ID+1)]:e(1)}));assert.throws(()=>validateEvents({'pick:1':e(1,Date.now()+600000)}));assert.throws(()=>validateEvents({'__proto__:1':e(1)}));assert.ok(Buffer.byteLength(JSON.stringify(makeBatch({events:{'pick:1':e(0)},resume:resume()})))<28000);
});
test('new bank IDs and global-source resume validate while old saved formats remain valid',()=>{
 assert.equal(MAX_QUESTION_ID,3206);
 assert.equal(validateEvents({'pick:1830':e(1),'pick:1924':e(2),'pick:3206':e(3)})['pick:3206'].v,3);
 const legacy=validateResume(resume());assert.deepEqual(legacy.v.config.sources,{});
 const config={...cfg,sourceFamilies:['formatives','nms','ai','examtips'],cursorId:3206,unansweredPendingId:1830};delete config.sources;
 const updated=validateResume({v:{config,cursors:{newbank:3206}},t:100,d:'A'});
 assert.deepEqual(updated.v.config.sourceFamilies,['formatives','nms','ai','examtips']);assert.equal(updated.v.config.cursorId,3206);
 assert.doesNotThrow(()=>validateResume({...updated,v:{...updated.v,config:{...config,sourceFamilies:null}}}));
 assert.throws(()=>validateResume({...updated,v:{...updated.v,config:{...config,sourceFamilies:['unknown']}}}));
 assert.throws(()=>validateResume({...updated,v:{...updated.v,cursors:{newbank:MAX_QUESTION_ID+1}}}));
});
test('stopping an old profile aborts work and ignores late responses',async()=>{
 let release;const s=server(),normal=s.transport('MO');const h=harness({s,transport:async req=>{const r=await normal(req);await new Promise(resolve=>release=resolve);return r}});const p=h.sync.start();await settle();h.sync.stop();release();await p;assert.deepEqual(h.cache.events,{});assert.equal(h.clock.timers.size,0);
});
test('a failed durable save is reported and memory changes still reach the cloud',async()=>{
 const storage=new Storage(),s=server();const h=harness({s,storage});await h.sync.start();storage.setItem=()=>{throw Error('quota')};h.sync.queue({events:{'pick:1':e(2)}});assert.equal(h.states.at(-1),'storage-error');await h.sync.flush();assert.equal(s.row('MO').events['pick:1'].v,2);
});
test('Retry-After postpones new edits as well as the failed batch',async()=>{
 const s=server(),normal=s.transport('MO');let attempts=0;const h=harness({s,transport:async req=>{if(req.method==='POST'&&++attempts===1)throw Object.assign(Error('throttled'),{status:429,retryAfter:60000});return normal(req)}});await h.sync.start();h.sync.queue({events:{'pick:1':e(1)}});await h.clock.tick(1500);h.sync.queue({events:{'mark:1':e(true)}});await h.clock.tick(59000);assert.equal(attempts,1);await h.clock.tick(1000);assert.equal(attempts,2);assert.equal(s.row('MO').events['mark:1'].v,true);
});
test('a stalled fetch times out and retains its unacknowledged delta',async()=>{
 const s=server(),normal=s.transport('MO');const h=harness({s,transport:req=>req.method==='GET'?normal(req):new Promise((resolve,reject)=>req.signal.addEventListener('abort',()=>reject(Error('timeout')),{once:true}))});await h.sync.start();h.sync.queue({events:{'pick:1':e(0)}});await h.clock.tick(13500);assert.equal(h.states.at(-1),'retry');assert.equal(h.sync.pending().events['pick:1'].v,0);h.sync.stop();
});

test('Full-list resume validates relative position, keeps legacy compatibility, and rejects invalid offsets',()=>{
 const config={...cfg,view:'list',cursorId:1900,cursorOffset:.45,index:450};
 assert.doesNotThrow(()=>validateResume({v:{config,cursors:{full:1900}},t:100,d:'A'}));
 assert.doesNotThrow(()=>validateResume(resume()));
 for(const cursorOffset of [-.1,1.1,NaN,'0.5',null])assert.throws(()=>validateResume({v:{config:{...config,cursorOffset},cursors:{}},t:100,d:'A'}));
});

test('two devices resume Full list in both directions without idle polling or repeated position writes',async()=>{
 const s=server(),a=harness({s}),b=harness({s,actor:'B'});await a.sync.start();await b.sync.start();
 const at=(id,offset,t,d)=>({v:{config:{...cfg,view:'list',cursorId:id,cursorOffset:offset,index:300},cursors:{full:id}},t,d});
 a.sync.queue({resume:at(940,.4,100,'A')});await a.sync.flush();await b.clock.tick(5001);await b.sync.wake();
 assert.equal(b.cache.resume.v.config.view,'list');assert.equal(b.cache.resume.v.config.cursorId,940);assert.equal(b.cache.resume.v.config.cursorOffset,.4);
 b.sync.queue({resume:at(1917,.65,200,'B')});await b.sync.flush();await a.clock.tick(5001);await a.sync.wake();
 assert.equal(a.cache.resume.v.config.cursorId,1917);assert.equal(a.cache.resume.v.config.cursorOffset,.65);
 const calls=s.calls.length,writes=s.writes;await a.clock.tick(3600000);await b.clock.tick(3600000);
 assert.equal(s.calls.length,calls);assert.equal(s.writes,writes);
});
