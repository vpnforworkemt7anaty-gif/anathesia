import test from 'node:test';
import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
import {createHash} from 'node:crypto';
import {webcrypto} from 'node:crypto';
import vm from 'node:vm';
import {createReviewLayer, normaliseOption,REVIEW_LABELS} from '../public/review-layer.js';
import {newer,mergeEvents as mergeEventMaps,realEvents,decodeLegacyResume} from '../public/study-sync.js';
import {validateResume} from '../lib/progress-model.ts';

const bankBytes=readFileSync(new URL('../public/questions.json',import.meta.url));
const questions=JSON.parse(bankBytes);
const meta=JSON.parse(readFileSync(new URL('../public/bank-meta.json',import.meta.url)));
const aiManifest=JSON.parse(readFileSync(new URL('../import-data/ai-examtips-bank.json',import.meta.url)));
const aiReviews=JSON.parse(readFileSync(new URL('../import-data/ai-examtips-reviews.json',import.meta.url)));
const data=JSON.parse(readFileSync(new URL('../public/review-notes.json',import.meta.url)));
const html=readFileSync(new URL('../public/study.html',import.meta.url),'utf8');
const groups=JSON.parse(html.match(/const DUPLICATE_GROUPS=(\[.*?\]);/s)[1]);
const roots=new Map(groups.flatMap(g=>g.map(id=>[id,g[0]])));
const rootOf=id=>roots.get(id)??id;
const layer=createReviewLayer(data,rootOf);
const byId=new Map(questions.map(q=>[q.id,q]));

test('all canonical questions and original occurrences have a substantive review',()=>{
  assert.equal(new Set(questions.map(q=>rootOf(q.id))).size,meta.reviewCanonicalQuestions);
  assert.equal(Object.keys(data.reviews).length,meta.reviewCanonicalQuestions);
  assert.equal(data.coverage.unreviewed,0);
  for(const q of questions){
    const r=layer.get(q);assert.ok(r,`Missing review ${q.id}`);
    assert.ok(r.concepts.length||r.notes.some(n=>n.text.length>40),`Empty review ${q.id}`);
    for(const c of r.concepts)assert.ok(data.concepts[c],`Missing concept ${c}`);
  }
});
test('all original records and IDs remain byte-identical within the appended bank',()=>{
  assert.equal(questions.length,3206);
  assert.equal(createHash('sha256').update(JSON.stringify(questions.slice(0,1829))).digest('hex'),'5b3e5b34c5536d0b5250a27538536c91b51b1ed8c52e9c26891d137012defd15');
  assert.equal(createHash('sha256').update(JSON.stringify(questions.slice(0,1924))+'\n').digest('hex'),aiManifest.originalBankSHA256);
});
test('AI and ExamTips preserve every checked transcription, original key and physical PDF reference',()=>{
  const imported=questions.filter(q=>q.importId==='ai-examtips');
  assert.equal(imported.length,1282);
  assert.equal(imported.filter(q=>q.ai).length,775);
  assert.equal(imported.filter(q=>!q.ai).length,507);
  for(const item of aiManifest.questions){
    const q=byId.get(item.id);
    assert.equal(q.q,item.q);assert.deepEqual(q.o,item.o);assert.equal(q.a,item.a);
    assert.equal(q.e,item.originalAnswer);assert.equal(q.key.text,item.originalAnswer);
    assert.deepEqual(q.sourcesNormalized,[item.source]);
    assert.equal(q.aiPdfPage,item.sourcePdfPage);assert.equal(q.aiKeyPdfPage,item.keyPdfPage);
    assert.equal(q.sourcePdfPage,undefined); // Never label this PDF as Bank 40.
    assert.ok(q.source.some(s=>s.includes('Q'+item.label)&&s.includes('PDF p. '+item.sourcePdfPage)));
    assert.ok(meta.branches[q.branch].includes(q.lecture));
    assert.equal(layer.originalChoice(q),item.a);assert.equal(layer.practiceGrade(q),item.a);
    assert.ok(aiReviews[`${item.lectureNumber}:${item.label}`].concepts.length);
  }
  for(const lecture of aiManifest.lectures){
    const items=imported.filter(q=>q.aiBookLectureNumber===lecture.number);
    assert.equal(items.filter(q=>q.ai).length,lecture.expectedAI);
    assert.equal(items.filter(q=>!q.ai).length,lecture.expectedExamTips);
  }
});
test('all page references are actual PDF pages and the full PDF is not a broken public link',()=>{
  for(const q of questions)for(const page of layer.pages(q))assert.ok(Number.isInteger(page)&&page>=1&&page<=384);
  assert.equal(data.source.url,undefined);
});
test('unique reviewed corrections and missing keys are graded by the correct option text',()=>{
  let corrections=0;
  for(const r of Object.values(data.reviews)){
    if(!r.correctOption)continue;
    const q=byId.get(r.representativeId);
    assert.equal(layer.grade(q),r.correctIndex,`Correction ${q.id}`);
    assert.equal(normaliseOption(q.o[layer.grade(q)]),normaliseOption(r.correctOption));
    corrections++;
  }
  assert.equal(corrections,25);
  assert.equal(layer.grade(byId.get(111)),2); // PPV, not routine meconium suction
  assert.equal(layer.grade(byId.get(315)),1); // renal biopsy
  assert.equal(layer.grade(byId.get(561)),1); // restored antibiotics exception
  assert.equal(layer.grade(byId.get(672)),1); // improving air entry
});
test('reordered, missing and duplicated alternatives never inherit a guessed letter',()=>{
  const q=byId.get(111),answer=q.o[2];
  assert.equal(layer.grade({...q,o:[answer,'other','another']}),0);
  assert.equal(layer.grade({...q,o:['missing','other']}),null);
  assert.equal(layer.grade({...q,o:[answer,answer]}),null);
});
test('ambiguous, uncovered and unresolved-conflict items cannot produce a false graded answer',()=>{
  for(const q of questions){
    const r=layer.get(q);
    if(['ambiguous','source-gap'].includes(r.status)||(r.status==='conflict'&&!r.correctOption))assert.equal(layer.grade(q),null,`Unsafe grade ${q.id}`);
  }
  assert.equal(layer.grade(byId.get(56)),null); // status changed after an earlier candidate correction
  assert.equal(layer.grade(byId.get(962)),null); // corrupt cyanosis definition
});
test('copy content preserves explicit recall reconstruction and separates external references',()=>{
  const recall=layer.copyText(byId.get(685));
  assert.match(recall,/not the recovered original wording/);
  assert.match(recall,/properly collected urine culture/i);
  assert.match(recall,/PDF page numbers:/);
  const emergency=layer.copyText(byId.get(501));
  assert.match(emergency,/External safety clarification/);
  assert.match(emergency,/worldallergyorganizationjournal.org/);
});
test('reading review and mapping grades never changes original question objects',()=>{
  const before=JSON.stringify(questions);
  for(const q of questions){layer.get(q);layer.grade(q);layer.pages(q);layer.copyText(q)}
  assert.equal(JSON.stringify(questions),before);
});

function studyContext({saved=new Map()}={}){
  const elements=new Map(),layouts=new Map(),scrolls=[],listeners={window:new Map(),document:new Map()};
  let time=0,timerId=0;const timers=new Map();
  const setTimer=(fn,delay=0)=>{const id=++timerId;timers.set(id,{at:time+delay,fn});return id};
  const clearTimer=id=>timers.delete(id);
  function tick(ms){const end=time+ms;let steps=0;for(;;){const next=[...timers].filter(([,t])=>t.at<=end).sort((a,b)=>a[1].at-b[1].at)[0];if(!next)break;assert.ok(++steps<10000,'UI timer loop');time=next[1].at;timers.delete(next[0]);next[1].fn()}time=end}
  const ids=new Set([...html.matchAll(/\bid="([^"]+)"/g)].map(m=>m[1]));
  const markup=()=>elements.get('#question-view')?.innerHTML||'';
  const cardIds=()=>[...markup().matchAll(/<article class="card" id="q-(\d+)"/g)].map(m=>Number(m[1]));
  let ctx;
  const addListener=(map,type,fn)=>{if(!map.has(type))map.set(type,[]);map.get(type).push(fn)};
  const element=selector=>{
    if(selector==='#question-view > .card')return cardIds().length?element('#q-'+cardIds()[0]):null;
    const control=/^#q-(\d+) \[data-(choice|reveal|retry)="([^"]+)"\]$/.exec(selector);
    if(control)return queryAll('[data-'+control[2]+']').find(x=>x.dataset[control[2]]===control[3])||null;
    if(/^#q-\d+$/.test(selector)&&!cardIds().includes(Number(selector.slice(3))))return null;
    if(/^#[\w-]+$/.test(selector)&&!/^#q-\d+$/.test(selector)&&!ids.has(selector.slice(1))&&!['#prev','#next','#load-more','#retry-all'].includes(selector))return null;
    if(!elements.has(selector)){
      const handlers=new Map(),attributes=new Map();const node={id:selector.slice(1),value:'',checked:false,open:false,scrollTop:0,innerHTML:'',textContent:'',dataset:{},classList:{contains:()=>false,toggle(){},add(){},remove(){}},
        addEventListener:(type,fn)=>addListener(handlers,type,fn),setAttribute:(k,v)=>attributes.set(k,v),getAttribute:k=>attributes.get(k),focus(){},
        showModal(){this.open=true},close(){this.open=false;this.dispatch('close')},
        dispatch(type,event={}){if(type==='click')this.onclick?.(event);for(const fn of [...(handlers.get(type)||[])])fn(event)},
        click(){this.dispatch('click',{target:this})},
        getBoundingClientRect(){if(selector==='.top')return {height:72,top:0};const id=Number(selector.slice(3));const layout=layouts.get(id)||{top:300+Math.max(0,cardIds().indexOf(id))*700,height:650};return {...layout,top:layout.top-(ctx?.window.scrollY||0)}}};
      if(selector==='#question-view'){
        let content='';
        Object.defineProperty(node,'innerHTML',{get:()=>content,set(value){
          // Rendering replaces descendants, just as assigning real DOM innerHTML does.
          for(const match of content.matchAll(/\bid="([^"]+)"/g))elements.delete('#'+match[1]);
          for(const key of [...elements.keys()])if(key.startsWith('@'))elements.delete(key);
          content=value;
        }});
      }
      elements.set(selector,node);
    }
    return elements.get(selector);
  };
  function queryAll(selector){
    if(selector==='#question-view > .card')return cardIds().map(id=>element('#q-'+id));
    if(selector==='#question-view details')return [...markup().matchAll(/<details\b[^>]*>/g)].map((m,i)=>{const node=element('@details:'+i);node.open=/\sopen(?:\s|>)/.test(m[0]);return node});
    const attr=/^\[data-([\w-]+)\]$/.exec(selector);if(!attr)return [];
    const key=attr[1].replace(/-([a-z])/g,(_,c)=>c.toUpperCase());
    return [...markup().matchAll(new RegExp('<[^>]+data-'+attr[1]+'="([^"]+)"[^>]*>','g'))].map(m=>{
      const node=element('@'+attr[1]+':'+m[1]);node.dataset[key]=m[1];node.disabled=/\sdisabled(?:\s|>)/.test(m[0]);return node;
    });
  }
  const ui={elements,saved,layouts,scrolls,tick,element,queryAll,emitWindow:(type,e)=>{for(const fn of listeners.window.get(type)||[])fn(e)},emitDocument:(type,e)=>{for(const fn of listeners.document.get(type)||[])fn(e)}};
  const bodyClasses=new Set(['study-single']);
  ctx=vm.createContext({createReviewLayer,normaliseOption,newer,mergeEventMaps,realEvents,decodeLegacyResume,REVIEW_LABELS,
    document:{querySelector:element,querySelectorAll:queryAll,addEventListener:(type,fn)=>addListener(listeners.document,type,fn),visibilityState:'visible',body:{classList:{contains:k=>bodyClasses.has(k),add:k=>bodyClasses.add(k),remove:k=>bodyClasses.delete(k),toggle(k,force){const on=force??!bodyClasses.has(k);if(on)bodyClasses.add(k);else bodyClasses.delete(k);return on}}}},
    window:{addEventListener:(type,fn)=>addListener(listeners.window,type,fn),innerWidth:1024,innerHeight:900,scrollY:0,scrollTo(options){this.scrollY=options.top;scrolls.push(options)},setTimeout:setTimer},
    localStorage:{getItem:k=>saved.get(k)??null,setItem:(k,v)=>saved.set(k,String(v)),removeItem:k=>saved.delete(k)},
    crypto:webcrypto,navigator:{onLine:false},setTimeout:setTimer,clearTimeout:clearTimer,requestAnimationFrame:fn=>setTimer(fn,16),console,
    createStudySync:()=>{throw Error('UI content test must not open cloud sync')},
    fetch:()=>{throw Error('UI content test must not make network requests')},bank:questions,notes:data,_ui:ui});
  let script=html.split('<script type="module">')[1].split('</script>')[0];
  script=script.replace(/^import .*?;\s*$/gm,'').replace(/\nboot\(\);\s*$/,'');
  vm.runInContext(script,ctx);
  vm.runInContext("ALL=bank;BYID=Object.fromEntries(ALL.map(q=>[q.id,q]));sourceReview=createReviewLayer(notes,reviewRootQuestion);selected=[...LECTURES];",ctx);
  return ctx;
}
test('actual renderer keeps the original answer primary and puts the correction in closed explanation',()=>{
  const ctx=studyContext();
  vm.runInContext('changedAnswer(BYID[315],1)',ctx);
  const markup=vm.runInContext('card(BYID[315],1)',ctx);
  const primary=markup.split('<details class="review-notes"')[0];
  assert.match(primary,/Original bank key: C\) 24 hour urine collection/);
  assert.doesNotMatch(primary,/data-answer-origin="assistant"/);
  assert.match(markup,/<details class="review-notes" aria-label=/);
  assert.doesNotMatch(markup,/<details class="review-notes"[^>]*\bopen\b/);
  assert.match(markup,/B\. Kidney biopsy to classify/);
  assert.match(markup,/PDF p\./);
  const copied=vm.runInContext('questionCopyText(BYID[315])',ctx);
  assert.match(copied,/Reviewed answer \(separate from original\): B\) Kidney biopsy/);
  assert.match(copied,/Original bank answer \(kept as supplied\): .*C\. 24 hour urine collection/);
  assert.match(copied,/360/);
});
test('actual recall UI retains original text, shows a labelled completion, then reveals its answer',()=>{
  const ctx=studyContext();
  const hidden=vm.runInContext('card(BYID[685],1)',ctx);
  assert.match(hidden,/dysuria/);
  assert.match(hidden,/تكملة مقترحة، وليست نص السؤال المفقود/);
  assert.doesNotMatch(hidden,/Suggested completion · إجابة التكملة/);
  vm.runInContext("changedAnswer(BYID[685],'shown')",ctx);
  const shown=vm.runInContext('card(BYID[685],1)',ctx);
  assert.match(shown,/Suggested completion · إجابة التكملة/);
  assert.match(shown,/properly collected urine culture/i);
});
test('actual renderer keeps an ambiguous original key selectable and labelled while its review remains unresolved',()=>{
  const ctx=studyContext();
  vm.runInContext('changedAnswer(BYID[962],0)',ctx);
  const markup=vm.runInContext('card(BYID[962],1)',ctx);
  assert.match(markup,/choice correct/);
  assert.match(markup,/Source answer · إجابة المصدر/);
  assert.ok(markup.indexOf('data-source-key-notice')<markup.indexOf('<p class="stem">'));
  assert.equal(layer.grade(byId.get(962)),null);
  assert.equal(layer.practiceGrade(byId.get(962)),0);
  const count=vm.runInContext("reviewFilter='conflict';filtered().filter(q=>sourceReview.get(q).status!=='conflict').length",ctx);
  assert.equal(count,0);
});

test('all 95 Bank 40 occurrences retain their section sources, wording, original keys and page references',()=>{
  const manifest=JSON.parse(readFileSync(new URL('../import-data/question-bank40.json',import.meta.url)));
  const imported=questions.filter(q=>q.importId==='bank40');
  assert.equal(imported.length,95);
  assert.equal(imported.filter(q=>q.type==='SAQ').length,3);
  assert.deepEqual(imported.map(q=>q.id),Array.from({length:95},(_,i)=>1830+i));
  const expectedCounts={
    'Formative 4 — Nephrology':10,'Formative 6 — Cardiology':14,
    'Lecture MCQs — Cyanotic & Acyanotic Congenital Heart Disease':15,
    'Formative 10 — Rheumatology':21,'Formative 11 — Hepatology':10,'Formative 12 — Neonatology':25,
  };
  assert.deepEqual(Object.fromEntries(Object.entries(expectedCounts).map(([name])=>[name,imported.filter(q=>q.sourcesNormalized.includes(name)).length])),expectedCounts);
  for(const item of manifest.questions){
    const q=byId.get(item.id);
    assert.deepEqual(q.sourcesNormalized,[item.section]);
    assert.equal(q.q,item.q);assert.deepEqual(q.o,item.o);assert.equal(q.e,item.originalAnswer);assert.equal(q.a,item.a);
    assert.ok(q.sourcePdfPage>=3&&q.sourcePdfPage<=21);
    assert.deepEqual(q.key.pages,item.keyPages);
    assert.ok(q.key.pages.every(p=>p>=4&&p<=22));
    assert.equal(rootOf(q.id),item.duplicateOf?rootOf(item.duplicateOf):q.id);
  }
  assert.equal(new Set(imported.map(q=>rootOf(q.id))).size,95);
  for(let i=1890;i<=1899;i++)assert.equal(byId.get(i).upstreamQuestionNumber,byId.get(i).num+2);
});
test('new ambiguous cardiac questions and age-unspecified tumour key never force a single answer',()=>{
  for(const id of [1835,1838,1865,1866,1878,1923])assert.equal(layer.grade(byId.get(id)),null,`Unsafe new key ${id}`);
  assert.match(layer.copyText(byId.get(1866)),/BOTH B/);
  assert.match(layer.copyText(byId.get(1865)),/CRITICAL pulmonary stenosis/);
  assert.match(layer.copyText(byId.get(1835)),/uroweb.org/);
  assert.match(layer.copyText(byId.get(1876)),/12 months/);
  assert.match(layer.copyText(byId.get(1904)),/External CDC/);
  assert.deepEqual(layer.pages(byId.get(1904)),[79]);
});
test('source-filtered reordered duplicates use the new version key without resetting old attempts',()=>{
  const ctx=studyContext();
  vm.runInContext("sourceChoice=['formatives'];selected=['APGAR score'];changedAnswer(BYID[13],0);",ctx);
  assert.equal(vm.runInContext('picked(BYID[1916])',ctx),0);
  vm.runInContext('changedAnswer(BYID[14],0)',ctx);
  assert.equal(vm.runInContext('picked(BYID[1917])',ctx),3); // existing A becomes D
  assert.equal(vm.runInContext('getValue("wrong",1917)',ctx),undefined);
  vm.runInContext('changedAnswer(BYID[1917],2)',ctx);
  assert.equal(vm.runInContext('picked(BYID[14])',ctx),1); // postnatal maturity maps back to B
  assert.equal(vm.runInContext('picked(BYID[1917])',ctx),2);
  vm.runInContext('changedAnswer(BYID[1917],null)',ctx);
  assert.equal(vm.runInContext('picked(BYID[14])',ctx),undefined);
  assert.equal(layer.grade(byId.get(1917)),3); // reordered X-ray choice; original is A
  assert.equal(layer.grade(byId.get(1901)),0); // reordered Klebsiella choice; original is B
  assert.equal(vm.runInContext('filtered().length',ctx),10);
  assert.equal(vm.runInContext('filtered().every(q=>q.importId===\'bank40\')',ctx),true);
  const tags=vm.runInContext('visibleSourceTags(BYID[1917])',ctx);
  assert.doesNotMatch(tags,/>Formatives<|>Exams 37–39</);
  assert.match(tags,/Formative 12/);
  assert.match(tags,/Bank 40 PDF p\. 20/);
  assert.doesNotMatch(tags,/SEQ p\. 20/);
});
test('new written questions reveal their complete supplied model and explanation without grading',()=>{
  const ctx=studyContext();
  const hidden=vm.runInContext('card(BYID[1869],1)',ctx);
  assert.match(hidden,/Reveal model answer/);
  assert.doesNotMatch(hidden,/Fever for ≥5 days/);
  vm.runInContext("changedAnswer(BYID[1869],'shown')",ctx);
  const shown=vm.runInContext('card(BYID[1869],1)',ctx);
  assert.match(shown,/Supplied model answer/);
  assert.match(shown,/Kawasaki is a clinical pattern/);
  assert.match(shown,/377/);
  assert.equal(layer.grade(byId.get(1869)),null);
  const copied=vm.runInContext('questionCopyText(BYID[1869])',ctx);
  assert.match(copied,/Supplied model answer:/);
  assert.match(copied,/Cervical lymphadenopathy/);
});

test('all original answers remain primary and every missing answer has a labelled source-based addition',()=>{
  assert.equal(createHash('sha256').update(JSON.stringify(questions.slice(0,1924))+'\n').digest('hex'),'cf8994ad5cd5db5f20d2b58a17ccd3669b74f4d4b9fee58238a87ac3c4b08e26');
  const ctx=studyContext();
  const audit=vm.runInContext(`(()=>{
    let originals=0,added=0;
    for(const q of ALL){
      const markup=answer(q),primary=markup.split('<details class="review-notes"')[0];
      if(sourceReview.hasOriginalAnswer(q)){
        if(!primary.includes('data-answer-origin="source"'))throw Error('Original hidden: '+q.id);
        if(Number.isInteger(q.a)&&!primary.includes(esc(q.o[q.a])))throw Error('Original key lost: '+q.id);
        originals++;
      }else{
        const addition=sourceReview.addedAnswer(q);
        if(!addition?.text||!addition.pages.length||addition.author!=='assistant'||!addition.notOriginalBankKey)throw Error('Missing authored answer: '+q.id);
        if(!primary.includes('data-answer-origin="assistant"')||!primary.includes(esc(addition.text)))throw Error('Added answer hidden: '+q.id);
        added++;
      }
      if(/<details class="review-notes"[^>]*\\bopen\\b/.test(markup))throw Error('Explanation opened: '+q.id);
    }
    return {originals,added};
  })()`,ctx);
  assert.equal(audit.originals+audit.added,questions.length);
  assert.ok(audit.added>28);
  assert.equal(Object.values(data.reviews).filter(r=>r.addedAnswer).length,28);
  assert.match(layer.copyText(byId.get(121)),/not a recovered original grade question/);
  assert.match(layer.copyText(byId.get(208)),/original cannot be recovered/);
});
test('one global source section uses eight groups across all lectures and saves a shared selection',()=>{
  const ctx=studyContext();
  assert.equal(vm.runInContext('sourceCounts().length',ctx),8);
  assert.equal(vm.runInContext('ALL.every(q=>questionFamilies(q).every(id=>id!=="other"))',ctx),true);
  const result=vm.runInContext("sourceChoice=['formatives'];selected=[...LECTURES];({items:filtered().length,lectures:new Set(filtered().map(q=>q.lecture)).size,valid:filtered().every(q=>questionFamilies(q).includes('formatives')),snapshot:configSnapshot()})",ctx);
  assert.ok(result.items>=80);assert.ok(result.lectures>10);assert.equal(result.valid,true);
  assert.equal(JSON.stringify(result.snapshot.sourceFamilies),'["formatives"]');
  assert.equal(result.snapshot.sources,undefined);
  assert.doesNotThrow(()=>validateResume({v:{config:result.snapshot,cursors:{}},t:100,d:'ui'}));
  assert.doesNotMatch(html,/data-expand=|data-for=|id="source-advanced"|id="hide-duplicates"/);
  const none=vm.runInContext("sourceChoice=[];filtered().length",ctx);assert.equal(none,0);
  vm.runInContext('sourceChoice=null',ctx);
  assert.equal(vm.runInContext('filtered().length',ctx),meta.uniqueQuestions);
});
test('additional repeats appear once while distinct qualifiers and every review identity survive',()=>{
  const ctx=studyContext();
  assert.equal(vm.runInContext('showUnique(ALL).length',ctx),meta.uniqueQuestions);
  for(const [a,b] of [[46,50],[781,801],[119,128],[568,1886],[571,1888],[275,1891]]){
    assert.equal(vm.runInContext(`rootQuestion(${a})===rootQuestion(${b})`,ctx),true);
  }
  for(const [a,b] of [[13,22],[18,35],[1088,1089],[1860,1866],[142,143],[408,410],[412,413],[175,181]]){
    assert.equal(vm.runInContext(`rootQuestion(${a})===rootQuestion(${b})`,ctx),false,`Different clinical qualifier ${a}/${b}`);
  }
  assert.equal(vm.runInContext('sourceReview.get(BYID[128]).representativeId',ctx),128);
  assert.equal(vm.runInContext('sourceReview.get(BYID[119]).representativeId',ctx),119);
  vm.runInContext('changedAnswer(BYID[128],0)',ctx);
  assert.equal(vm.runInContext('picked(BYID[119])',ctx),0);
  assert.equal(vm.runInContext('picked(BYID[1901])',ctx),2);
  vm.runInContext('changedAnswer(BYID[128],1)',ctx); // old misspelling: keep completion rather than guessing
  assert.equal(vm.runInContext('picked(BYID[119])',ctx),'shown');
});

test('precise original sources appear above the stem while the global picker stays grouped',()=>{
  const ctx=studyContext();
  for(const id of [1917,1830,1850,315]){
    const result=vm.runInContext(`({markup:card(BYID[${id}],1),sources:uniqueValue(BYID[${id}]).flatMap(q=>q.sourcesNormalized)})`,ctx);
    const above=result.markup.split('<p class="stem">')[0];
    assert.match(above,/Question source · مصدر السؤال/);
    for(const source of result.sources)assert.ok(above.includes(source.replaceAll('&','&amp;')),`Missing source ${source}`);
    assert.doesNotMatch(above,/>Exams 37–39<|>Formatives<|>Lectures &amp; doctors</);
  }
  const tags=vm.runInContext('visibleSourceTags(BYID[1917])',ctx);
  assert.match(tags,/Formative 12 — Neonatology/);
  assert.match(tags,/Bank 40 PDF p\. 20/);
  assert.equal(vm.runInContext('sourceCounts().length',ctx),8);
});

test('new source groups work across lectures, retain precise subtypes and save the final imported question',()=>{
  const ctx=studyContext();
  for(const [family,count] of [['ai',775],['examtips',507]]){
    const result=vm.runInContext(`sourceChoice=['${family}'];selected=[...LECTURES];({count:filtered().length,valid:filtered().every(q=>questionFamilies(q).includes('${family}')),snapshot:configSnapshot()})`,ctx);
    assert.equal(result.count,count);assert.equal(result.valid,true);
    assert.doesNotThrow(()=>validateResume({v:{config:result.snapshot,cursors:{}},t:100,d:'new-bank'}));
  }
  const last=vm.runInContext('visibleSourceTags(BYID[3206])',ctx);
  assert.match(last,/ExamTips ·/);assert.match(last,/QE27/);assert.match(last,/PDF p\. 130/);
  assert.doesNotMatch(last,/Bank 40/);
  for(const id of [2385,2413,2551]){
    const q=byId.get(id);assert.ok(q);
    const result=vm.runInContext(`({card:card(BYID[${id}],1),answer:answer(BYID[${id}])})`,ctx);
    if(['conflict','ambiguous'].includes(layer.get(q).status)){
      assert.ok(result.card.indexOf('source-key-alert')<result.card.indexOf('<p class="stem">'));
      assert.match(result.card,/source-key-alert/);
    }
    assert.ok(result.answer.split('<details class="review-notes"')[0].includes(q.o[q.a].replaceAll('&','&amp;').replaceAll('<','&lt;').replaceAll('>','&gt;')));
    assert.doesNotMatch(result.answer,/<details class="review-notes"[^>]*\bopen\b/);
  }
  for(const [a,b] of [[781,2747],[2308,2365],[2929,2956]])assert.equal(vm.runInContext(`rootQuestion(${a})===rootQuestion(${b})`,ctx),true);
  for(const [a,b] of [[2203,2206],[1981,1982],[2936,2941],[2009,2060],[2273,2346]])assert.equal(vm.runInContext(`rootQuestion(${a})===rootQuestion(${b})`,ctx),false);
});

test('unanswered questions stay in the same set after answers, next, remote updates and filter changes until refresh',()=>{
  const saved=new Map(),ctx=studyContext({saved});
  vm.runInContext("selected=['APGAR score'];mode='unanswered';autoNext=false;render();",ctx);
  const ids=vm.runInContext('CURRENT.map(q=>q.id).join(",")',ctx);
  const [first,second,third]=vm.runInContext('CURRENT.slice(0,3).map(q=>q.id)',ctx);
  vm.runInContext(`changedAnswer(BYID[${first}],sourceReview.grade(BYID[${first}]));render();next();`,ctx);
  assert.equal(vm.runInContext('CURRENT.map(q=>q.id).join(",")',ctx),ids);
  assert.equal(vm.runInContext('index',ctx),1);
  vm.runInContext(`changedAnswer(BYID[${second}],'shown');render();mergeRemote({events:{'pick:${third}':{v:'shown',t:Date.now()+1000,d:'second-device'}}});mode='all';render();mode='unanswered';render();`,ctx);
  assert.equal(vm.runInContext('CURRENT.map(q=>q.id).join(",")',ctx),ids);
  const refreshed=studyContext({saved:new Map(saved)});
  vm.runInContext("loadEvents();selected=['APGAR score'];mode='unanswered';render();",refreshed);
  for(const id of [first,second,third])assert.equal(vm.runInContext(`CURRENT.some(q=>rootQuestion(q.id)===rootQuestion(${id}))`,refreshed),false);
  assert.equal(vm.runInContext('CURRENT.length',refreshed),ids.split(',').length-3);
});

test('initial cloud hydration excludes older solved questions but keeps answers made during the current page session',()=>{
  const ctx=studyContext();
  vm.runInContext("activeProfile='MO';selected=['APGAR score'];mode='unanswered';render();",ctx);
  const [local,remote,later]=vm.runInContext('CURRENT.slice(0,3).map(q=>q.id)',ctx);
  vm.runInContext(`changedAnswer(BYID[${local}],0);mergeRemote({events:{'pick:${remote}':{v:'shown',t:Date.now(),d:'cloud'}}},true);`,ctx);
  assert.equal(vm.runInContext(`CURRENT.some(q=>q.id===${local})`,ctx),true);
  assert.equal(vm.runInContext(`CURRENT.some(q=>q.id===${remote})`,ctx),false);
  vm.runInContext(`mergeRemote({events:{'pick:${later}':{v:'shown',t:Date.now()+10,d:'cloud'}}});`,ctx);
  assert.equal(vm.runInContext(`CURRENT.some(q=>q.id===${later})`,ctx),true);
  vm.runInContext("activeProfile='Basant';events={};render();",ctx);
  assert.equal(vm.runInContext(`CURRENT.some(q=>q.id===${remote})`,ctx),true);
});

test('Auto-next advances an answered question with an explanation, including keyboard input, and cancels when disabled',()=>{
  const ctx=studyContext(),ui=ctx._ui;
  vm.runInContext("selected=['APGAR score'];autoNext=true;delay=450;render();",ctx);
  const key=vm.runInContext('(CURRENT[0].letters||LL.split(""))[sourceReview.grade(CURRENT[0])]',ctx);
  let prevented=false;
  ui.emitDocument('keydown',{key,code:'Key'+key,target:{closest:()=>null},preventDefault(){prevented=true}});
  assert.equal(prevented,true);
  assert.notEqual(vm.runInContext('picked(CURRENT[0])',ctx),undefined);
  assert.match(ui.element('#question-view').innerHTML,/<details class="review-notes"/);
  assert.doesNotMatch(ui.element('#question-view').innerHTML,/<details class="review-notes"[^>]*\bopen\b/);
  ui.tick(449);assert.equal(vm.runInContext('index',ctx),0);
  ui.tick(1);assert.equal(vm.runInContext('index',ctx),1);
  ui.tick(32);
  const choice=ui.queryAll('[data-choice]').find(b=>!b.disabled);choice.click();
  ui.element('#autonext').onchange({target:{checked:false}});
  ui.tick(1000);assert.equal(vm.runInContext('index',ctx),1);
  assert.doesNotMatch(html,/id="pause-notes"/);
});

test('Auto-next in Full list scrolls to the next card across the Load more boundary',()=>{
  const ctx=studyContext(),ui=ctx._ui;
  vm.runInContext("view='list';autoNext=true;delay=450;render();",ctx);
  assert.equal(vm.runInContext('validMCQ(CURRENT[199])',ctx),true);
  const id=vm.runInContext('CURRENT[199].id',ctx);
  const choice=ui.queryAll('[data-choice]').find(b=>b.dataset.choice.startsWith(id+':'));
  assert.ok(choice);choice.click();ui.tick(450);ui.tick(32);
  assert.equal(vm.runInContext('index',ctx),200);
  assert.equal(vm.runInContext('listLimit',ctx),400);
  const target=vm.runInContext('CURRENT[200].id',ctx);
  const rect=ui.element('#q-'+target).getBoundingClientRect();
  assert.equal(rect.top,84);
  assert.ok(ui.scrolls.length);
});

test('Space reveals the answer, waits the selected delay and advances without scrolling or repeating a held key',()=>{
  const ctx=studyContext(),ui=ctx._ui;
  vm.runInContext("selected=['APGAR score'];view='single';autoNext=true;delay=750;render();",ctx);
  let prevented=0;
  const space=(repeat=false)=>ui.emitDocument('keydown',{key:' ',code:'Space',repeat,target:{closest:()=>null},preventDefault(){prevented++}});
  space();
  assert.equal(vm.runInContext('picked(CURRENT[0])',ctx),'shown');
  assert.match(ui.element('#question-view').innerHTML,/data-answer-origin="source"/);
  ui.tick(749);assert.equal(vm.runInContext('index',ctx),0);
  ui.tick(1);assert.equal(vm.runInContext('index',ctx),1);
  space(true);ui.tick(1500);
  assert.equal(vm.runInContext('index',ctx),1);
  assert.equal(vm.runInContext('picked(CURRENT[1])',ctx),undefined);
  assert.equal(prevented,2);assert.equal(ui.scrolls.length,0);
});

test('Space also advances written/model answers, while clicking Reveal leaves them available to read',()=>{
  const ctx=studyContext(),ui=ctx._ui;
  vm.runInContext("typeChoice=['SAQ','Show Answer'];autoNext=true;delay=450;render();",ctx);
  assert.ok(vm.runInContext('CURRENT.length>1&&!validMCQ(CURRENT[0])',ctx));
  const id=vm.runInContext('CURRENT[0].id',ctx);
  ui.queryAll('[data-reveal]')[0].click();ui.tick(2000);
  assert.equal(vm.runInContext('index',ctx),0);
  vm.runInContext(`changedAnswer(BYID[${id}],null);refreshCard(${id})`,ctx);
  const button=ui.queryAll('[data-reveal]')[0];
  // A keyboard-focused Reveal button uses the same Space behaviour, once.
  ui.emitDocument('keydown',{key:' ',code:'Space',target:{closest:selector=>selector==='[data-reveal]'||selector.startsWith('summary,button')?button:null},preventDefault(){}});
  assert.equal(vm.runInContext('picked(CURRENT[0])',ctx),'shown');
  ui.tick(449);assert.equal(vm.runInContext('index',ctx),0);
  ui.tick(1);assert.equal(vm.runInContext('index',ctx),1);
});

test('Space Auto-next respects its toggle and pauses when the optional explanation opens',()=>{
  for(const stop of ['toggle','explanation']){
    const ctx=studyContext(),ui=ctx._ui;
    vm.runInContext("selected=['APGAR score'];autoNext=true;delay=450;render();",ctx);
    ui.emitDocument('keydown',{key:' ',code:'Space',target:{closest:()=>null},preventDefault(){}});
    assert.equal(vm.runInContext('picked(CURRENT[0])',ctx),'shown');
    if(stop==='toggle')ui.element('#autonext').onchange({target:{checked:false}});
    else{const details=ui.queryAll('#question-view details')[0];assert.ok(details);details.open=true;details.dispatch('toggle')}
    ui.tick(2000);assert.equal(vm.runInContext('index',ctx),0,stop);
  }
});

test('opening a source explanation pauses the pending Auto-next so it can be read',()=>{
  const ctx=studyContext(),ui=ctx._ui;
  vm.runInContext("selected=['APGAR score'];autoNext=true;render();",ctx);
  ui.queryAll('[data-choice]').find(b=>!b.disabled).click();
  const details=ui.queryAll('#question-view details')[0];
  assert.ok(details);details.open=true;details.dispatch('toggle');
  ui.tick(1500);assert.equal(vm.runInContext('index',ctx),0);
});

test('controls stay in a closed dialog, pause Auto-next and block answer/navigation shortcuts until closed',()=>{
  const ctx=studyContext(),ui=ctx._ui;
  vm.runInContext("selected=['APGAR score'];autoNext=true;render();",ctx);
  const initial=vm.runInContext('CURRENT[index].id',ctx);
  assert.equal(ui.element('#study-controls').open,false);
  ui.queryAll('[data-choice]').find(b=>!b.disabled).click();
  ui.element('#open-controls').click();
  assert.equal(ui.element('#study-controls').open,true);
  assert.equal(ui.element('#open-controls').getAttribute('aria-expanded'),'true');
  ui.tick(1500);
  ui.emitDocument('keydown',{key:'ArrowRight',target:{closest:()=>null},preventDefault(){throw Error('Handled a blocked shortcut')}});
  assert.equal(vm.runInContext('CURRENT[index].id',ctx),initial);
  ui.element('#done-controls').click();
  assert.equal(ui.element('#study-controls').open,false);
  assert.equal(ui.element('#open-controls').getAttribute('aria-expanded'),'false');
  assert.equal(vm.runInContext('CURRENT[index].id',ctx),initial);
  const start=html.indexOf('<dialog id="study-controls"'),end=html.indexOf('</dialog>',start);
  for(const id of ['dashboard','mode-filter','layout','search','review-filter','autonext','active-filters'])assert.ok(html.indexOf(`id="${id}"`,start)<end,`Control left outside the dialog: ${id}`);
});

test('single-question next/previous reset only the reading card and never scroll the page',()=>{
  const ctx=studyContext(),ui=ctx._ui;
  vm.runInContext("selected=['APGAR score'];view='single';render();",ctx);
  const first=vm.runInContext('CURRENT[0].id',ctx);
  ui.element('#q-'+first).scrollTop=450;
  ui.element('#next').click();ui.tick(32);
  const second=vm.runInContext('CURRENT[1].id',ctx);
  assert.equal(ui.element('#q-'+second).scrollTop,0);
  ui.element('#q-'+second).scrollTop=290;
  ui.element('#prev').click();ui.tick(32);
  assert.equal(ui.element('#q-'+first).scrollTop,0);
  assert.equal(ui.scrolls.length,0);
  assert.equal(vm.runInContext('document.body.classList.contains("study-single")',ctx),true);
  vm.runInContext("view='list';render()",ctx);
  assert.equal(vm.runInContext('document.body.classList.contains("study-single")',ctx),false);
});

test('answer reveals, bookmarks and incoming progress keep the current single-card reading position',()=>{
  const ctx=studyContext(),ui=ctx._ui;
  vm.runInContext("selected=['APGAR score'];view='single';autoNext=false;render();",ctx);
  const id=vm.runInContext('CURRENT[0].id',ctx);
  ui.element('#q-'+id).scrollTop=315;
  ui.queryAll('[data-reveal]')[0].click();
  assert.equal(ui.element('#q-'+id).scrollTop,315);
  vm.runInContext(`touch('mark',${id},true);refreshCard(${id});mergeRemote({events:{'mark:3206':{v:true,t:Date.now()+1000,d:'other-device'}}});`,ctx);
  assert.equal(ui.element('#q-'+id).scrollTop,315);
  assert.equal(ui.scrolls.length,0);
});

test('Full list saves a debounced question anchor and restores it on another screen beyond the first 200 cards',()=>{
  const saved=new Map(),ctx=studyContext({saved}),ui=ctx._ui;
  vm.runInContext("activeProfile='MO';view='list';sessionHydrated=true;render();",ctx);
  const ids=vm.runInContext('CURRENT.map(q=>q.id)',ctx);
  // Load the page containing the target; document coordinates match a tall screen.
  vm.runInContext('listLimit=400;render()',ctx);
  for(let i=0;i<400;i++)ui.layouts.set(ids[i],{top:300+i*1000,height:980});
  ctx.window.scrollY=300+250*1000+980*.4-84;
  ui.emitWindow('scroll');ui.tick(399);assert.equal(vm.runInContext('index',ctx),0);
  ui.tick(1);assert.equal(vm.runInContext('index',ctx),250);
  assert.equal(vm.runInContext('cursorOffset',ctx),.4);
  const cfg=JSON.parse(saved.get('ped2-profile-v3::mo:config'));
  assert.equal(cfg.view,'list');assert.equal(cfg.cursorId,ids[250]);assert.equal(cfg.cursorOffset,.4);
  const envelope=JSON.parse(saved.get('ped2-profile-v3::mo:resume-v4'));
  assert.doesNotThrow(()=>validateResume(envelope));
  const other=studyContext(),small=other._ui;
  for(let i=0;i<400;i++)small.layouts.set(ids[i],{top:150+i*600,height:580});
  other.transfer=JSON.parse(JSON.stringify(envelope));
  vm.runInContext("activeProfile='MO';resumeState=transfer.v;applyCloudSession(transfer.v.config);",other);
  small.tick(32);
  assert.equal(vm.runInContext('index',other),250);
  assert.equal(vm.runInContext('listLimit',other),400);
  assert.equal(other.window.scrollY,150+250*600+580*.4-84);
  assert.equal(small.element('#q-'+ids[250]).getBoundingClientRect().top+580*.4,84);
  const before=JSON.parse(saved.get('ped2-profile-v3::mo:resume-v4')).t;
  ui.emitWindow('scroll');ui.tick(1000);
  assert.equal(JSON.parse(saved.get('ped2-profile-v3::mo:resume-v4')).t,before,'Unchanged position must not queue more writes');
  ctx.window.scrollY=300+251*1000-84;ui.emitWindow('pagehide');
  assert.equal(JSON.parse(saved.get('ped2-profile-v3::mo:config')).cursorId,ids[251]);
});

test('every supplied option key stays available for practice independently of medical review status',()=>{
  let covered=0,disputed=0;
  for(const q of questions){
    if(q.type!=='MCQ'||q.doc||q.seq||!Array.isArray(q.o)||q.o.length<2||!Number.isInteger(q.a)||q.a<0||q.a>=q.o.length)continue;
    assert.equal(layer.practiceGrade(q),q.a,`Original key replaced or hidden: ${q.id}`);
    if(['conflict','ambiguous','source-gap'].includes(layer.get(q)?.status))disputed++;
    covered++;
  }
  assert.ok(covered>1500);assert.ok(disputed>100);
  assert.equal(layer.grade(byId.get(315)),1);
  assert.equal(layer.practiceGrade(byId.get(315)),2);
  assert.equal(layer.grade(byId.get(923)),null);
  assert.equal(layer.practiceGrade(byId.get(923)),1);
});

test('the screenshot ARPKD question keeps original B in its normal answer position with an optional closed explanation',()=>{
  const ctx=studyContext(),ui=ctx._ui;
  vm.runInContext("selected=['Polycystic Kidney disease'];autoNext=false;render();index=CURRENT.findIndex(q=>rootQuestion(q.id)===rootQuestion(923));render();",ctx);
  const id=vm.runInContext('CURRENT[index].id',ctx);
  let markup=ui.element('#question-view').innerHTML;
  assert.ok(markup.indexOf('data-source-key-notice')<markup.indexOf('<p class="stem">'));
  assert.doesNotMatch(markup,/No single verified choice|No unique verified answer/);
  const choices=ui.queryAll('[data-choice]').filter(b=>b.dataset.choice.startsWith(id+':'));
  assert.equal(choices.length,4);assert.ok(choices.every(b=>!b.disabled));
  choices[1].click();markup=ui.element('#question-view').innerHTML;
  assert.match(markup,new RegExp('class="choice correct" data-choice="'+id+':1"'));
  assert.match(markup,/Source answer · إجابة المصدر/);
  assert.match(markup,/Original bank key: B\) Liver cysts may be present/);
  assert.equal(vm.runInContext(`getValue('wrong',${id})`,ctx),undefined);
  const detailsAt=markup.indexOf('<details class="review-notes"');
  assert.ok(markup.indexOf('Original bank key: B) Liver cysts may be present')<detailsAt);
  assert.doesNotMatch(markup,/<details class="review-notes"[^>]*\bopen\b/);
  assert.ok(markup.indexOf('The PDF describes ARPKD')>detailsAt);
  assert.match(markup,/Add to wrong-answer review/);
  const copied=vm.runInContext(`questionCopyText(BYID[${id}])`,ctx);
  assert.match(copied,/Original bank answer \(kept as supplied\): B\. Liver cysts may be present/);
});

test('a corrected review cannot replace the source key in option highlighting or wrong-answer practice',()=>{
  const ctx=studyContext();
  vm.runInContext('changedAnswer(BYID[315],2)',ctx);
  let markup=vm.runInContext('card(BYID[315],1)',ctx);
  assert.match(markup,/class="choice correct" data-choice="315:2"/);
  assert.doesNotMatch(markup,/class="choice correct" data-choice="315:1"/);
  assert.equal(vm.runInContext('getValue("wrong",315)',ctx),undefined);
  assert.ok(markup.indexOf('data-source-key-notice')<markup.indexOf('<p class="stem">'));
  const primary=markup.split('<details class="review-notes"')[0];
  assert.match(primary,/Original bank key: C\) 24 hour urine collection/);
  assert.doesNotMatch(primary,/Reviewed answer:/);
  vm.runInContext('changedAnswer(BYID[315],1)',ctx);
  assert.equal(vm.runInContext('getValue("wrong",315)',ctx),true);
});

test('genuinely missing option keys do not acquire a fabricated original answer',()=>{
  const ctx=studyContext();
  for(const q of questions.filter(q=>q.type==='MCQ'&&(q.a===null||q.a===undefined||q.a<0))){
    assert.equal(layer.originalChoice(q),null);
    assert.equal(layer.practiceGrade(q),layer.grade(q));
  }
  const original=byId.get(923),missing={...original,a:-1,e:'Not provided in source.'};
  assert.equal(layer.originalChoice(missing),null);assert.equal(layer.practiceGrade(missing),null);
  ctx.missing=missing;
  const markup=vm.runInContext('card(missing,1)',ctx);
  assert.doesNotMatch(markup,/class="choice correct"/);
});
