// Small, durable delta queue. There is deliberately no polling interval.
export const newer=(a,b)=>!!a&&(!b||a.t>b.t||(a.t===b.t&&a.d>b.d));
export const dominates=(a,b)=>!!a&&!newer(b,a);
export function mergeEvents(a={},b={}){const out={...a};for(const [k,v] of Object.entries(b))if(newer(v,out[k]))out[k]=v;return out;}
export function decodeLegacyResume(events){
 const head=events['pick:990000'];if(!head||!Number.isInteger(head.v)||head.v<1||head.v>80)return null;
 let raw='';for(let i=1;i<=head.v;i++){const p=events[`pick:${990000+i}`];if(!p||p.t!==head.t||p.d!==head.d||typeof p.v!=='string')return null;raw+=p.v;}
 try{const data=JSON.parse(raw);return data.v===1&&data.config?{v:{config:data.config,cursors:data.cursors||{}},t:head.t,d:head.d}:null;}catch{return null;}
}
export const realEvents=events=>Object.fromEntries(Object.entries(events).filter(([k])=>!/^pick:9900\d\d$/.test(k)));
const bytes=value=>new TextEncoder().encode(JSON.stringify(value)).length;
let instances=0;
export function makeBatch(pending,maxBytes=28000){
 const batch={protocol:2,events:{}};
 if(pending.resume)batch.resume=pending.resume;
 for(const [k,v] of Object.entries(pending.events)){
  batch.events[k]=v;if(bytes(batch)>maxBytes){delete batch.events[k];break;}
 }
 if(bytes(batch)>maxBytes)throw Error('Resume data exceeds sync batch size');
 return batch;
}
export function createStudySync(options){
 const {storage,prefix,actor,transport,onRemote=()=>{},onStatus=()=>{},now=Date.now,
  setTimer=setTimeout,clearTimer=clearTimeout,online=()=>true,visible=()=>true,random=Math.random}=options;
 const partition=prefix+':outbox-v4:',ownPrefix=partition+actor+':'+now()+':'+(++instances),seedKey=prefix+':seeded-v4';let sequence=0;
 let timer=null,enabled=false,closed=false,inFlight=null,controller=null,etag=null,hydrated=false;
 let failures=0,retryAt=0,paused=false,firstPending=0,lastPush=-Infinity,lastPull=-Infinity;
 let memory={events:{}};
 const read=key=>{try{return JSON.parse(storage.getItem(key)||'null');}catch{return null;}};
 const status=s=>{if(!closed)onStatus(s);};
 function save(key,value){try{storage.setItem(key,JSON.stringify(value));return true;}catch{status('storage-error');return false;}}
 function partitions(){
  const found=[];for(let i=0;i<storage.length;i++){const k=storage.key(i);if(k?.startsWith(partition)){const v=read(k);if(v?.events)found.push([k,v]);}}
  return found;
 }
 function pending(){let result={events:{}};for(const [,p] of partitions().concat([[null,memory]])){result.events=mergeEvents(result.events,p.events);if(newer(p.resume,result.resume))result.resume=p.resume;}return result;}
 const hasPending=()=>{const p=pending();return !!p.resume||Object.keys(p.events).length>0;};
 function ack(remote,skipKey=null){
  const prune=p=>{const out={events:{...p.events}};for(const [k,v] of Object.entries(out.events))if(dominates(remote.events?.[k],v))delete out.events[k];if(p.resume&&!dominates(remote.resume,p.resume))out.resume=p.resume;return out;};
  // Re-read each partition after awaiting the response: edits made during the
  // request must survive an ACK for an older snapshot.
  for(const [k] of partitions()){if(k===skipKey)continue;const current=read(k);if(!current?.events)continue;const p=prune(current);if(Object.keys(p.events).length||p.resume){if(JSON.stringify(p)!==JSON.stringify(current))save(k,p);}else try{storage.removeItem(k);}catch{}}
  memory=prune(memory);
 }
 function cancel(){if(timer!==null)clearTimer(timer);timer=null;}
 function schedule(){
  cancel();if(!enabled||closed||paused||!online()||!visible()||!hasPending())return;
  if(!firstPending)firstPending=now();
  const due=Math.max(retryAt,lastPush+10000,Math.min(now()+1500,firstPending+10000));
  timer=setTimer(()=>{timer=null;void run(false);},Math.max(0,due-now()));
 }
 function queue(delta){
  if(closed)return;
  const value={events:mergeEvents(memory.events,delta.events)};
  const resume=[memory.resume,delta.resume].filter(Boolean).reduce((a,b)=>newer(b,a)?b:a,null);if(resume)value.resume=resume;
  // Each edit gets a new key: an ACK in another tab can never overwrite it.
  const ownKey=ownPrefix+':'+(++sequence);
  const persisted=save(ownKey,value);
  if(persisted){memory={events:{}};ack(value,ownKey);}else memory=value;
  status(persisted?(online()?'pending':'offline'):'storage-error');schedule();
 }
 function failure(error){
  if(closed)return;
  failures++;const code=error.status;
  paused=code===401||code===403||code===400||failures>=5;
  const retryAfter=Number(error.retryAfter)||0;
  retryAt=now()+Math.max(retryAfter,Math.min(300000,5000*2**(failures-1))*(0.8+random()*0.4));
  status(code===401||code===403?'signin':code===400?'rejected':!online()?'offline':paused?'waiting':'retry');
 }
 async function request(method,payload,keepalive=false){
  controller=new AbortController();const abort=setTimer(()=>controller?.abort(),12000);
  try{return await transport({method,payload,etag:method==='GET'?etag:null,signal:controller.signal,keepalive});}
  finally{clearTimer(abort);controller=null;}
 }
 async function run(pull=false,keepalive=false,force=false){
  if(closed||!enabled)return;
  if(!online()){status('offline');return;}
  if((!visible()&&!keepalive)||(!force&&(paused||now()<retryAt)))return;
  if(inFlight)return inFlight;
  cancel();
  inFlight=(async()=>{
   await Promise.resolve();
   try{
    status('syncing');
    if((pull||!hydrated)&&!keepalive){
     const remote=await request('GET');if(closed)return;
     if(!remote.notModified){onRemote(remote);ack(remote);etag=remote.etag||null;}
     hydrated=true;lastPull=now();
    }
    const delta=pending();
    if((delta.resume||Object.keys(delta.events).length)&&(!closed)&&(visible()||keepalive)){
     const batch=makeBatch(delta);lastPush=now();
     const remote=await request('POST',batch,keepalive);if(closed)return;
     // A POST only acknowledges its submitted keys. It cannot advance our
     // last-read ETag, since other devices may have changed unseen keys.
     onRemote(remote);ack(remote);
    }
    failures=0;retryAt=0;paused=false;firstPending=0;
    status(hasPending()?'pending':'synced');
   }catch(error){failure(error);}
   finally{inFlight=null;schedule();}
  })();
  return inFlight;
 }
 async function start(seed={events:{}}){
  if(closed)return;enabled=true;
  if(!read(seedKey)){queue(seed);if(!Object.keys(memory.events).length&&!memory.resume)save(seedKey,true);}
  return run(true,false,true);
 }
 function wake(){
  if(closed||!enabled||!visible()||!online())return;
  // Focus + visibilitychange + online often arrive together. Coalesce them.
  if(now()-lastPull<5000&&!paused){schedule();return;}
  failures=0;paused=false;retryAt=0;return run(true,false,true);
 }
 function hide(){cancel();if(hasPending()&&!inFlight&&!paused&&now()>=retryAt)return run(false,true);}
 function storageChanged(){if(!closed){status(hasPending()?'pending':'synced');schedule();}}
 function stop(){enabled=false;closed=true;cancel();controller?.abort();}
 return {queue,start,wake,hide,storageChanged,stop,pending,flush:()=>run(false,false,true)};
}
