/* Static source review. It never changes the original bank or saved attempts. */
export const REVIEW_LABELS = {
  supported: 'Explained from notes',
  clarified: 'Wording clarified',
  completed: 'Missing answer completed',
  conflict: 'Key/source conflict',
  ambiguous: 'Source-key ambiguity',
  partial: 'Partly covered by notes',
  'source-gap': 'Not covered by these notes',
};

export function normaliseOption(value) {
  return String(value ?? '').normalize('NFKC').toLowerCase()
    .replace(/[’‘]/g, "'").replace(/[–—]/g, '-').replace(/\s+/g, ' ').trim()
    .replace(/[.,;:]$/, '');
}

export function createReviewLayer(data, rootOf = id => id) {
  const get = q => data?.reviews?.[String(rootOf(q.id))] ?? null;
  const hasOriginalAnswer = q => {
    const text=String(q.docAnswer||q.e||'').trim();
    return (Number.isInteger(q.a)&&q.a>=0&&q.a<(q.o||[]).length)||!!text&&!/^(?:not provided(?: in (?:the )?source)?\.?|no (?:source )?answer(?: was)? (?:provided|available).*|\[missing\]|gm%)$/i.test(text);
  };
  const addedAnswer = q => !hasOriginalAnswer(q) ? get(q)?.addedAnswer??null : null;
  function grade(q) {
    const r = get(q);
    if (q.type !== 'MCQ' || q.doc || q.seq || !Array.isArray(q.o) || q.o.length < 2) return null;
    if (r && ['ambiguous', 'source-gap'].includes(r.status)) return null;
    if (r && ['conflict', 'completed'].includes(r.status)) {
      if (!r.correctOption) return null;
      const matches = q.o.map((text, index) => normaliseOption(text) === normaliseOption(r.correctOption) ? index : -1).filter(index => index >= 0);
      // Reordered duplicates must match the option text, never the old letter.
      return matches.length === 1 ? matches[0] : null;
    }
    return !q.w && Number.isInteger(q.a) && q.a >= 0 && q.a < q.o.length ? q.a : null;
  }
  // Practice follows the supplied bank key. A review may disagree with it or
  // leave the medical question unresolved without removing that original key.
  const originalChoice = q => q.type === 'MCQ' && !q.doc && !q.seq &&
    Array.isArray(q.o) && q.o.length >= 2 && Number.isInteger(q.a) &&
    q.a >= 0 && q.a < q.o.length ? q.a : null;
  const practiceGrade = q => originalChoice(q) ?? grade(q);
  const concepts = q => (get(q)?.concepts ?? []).map(key => data.concepts[key]).filter(Boolean);
  const pages = q => [...new Set([
    ...concepts(q).flatMap(c => c.pages ?? []),
    ...(get(q)?.notes ?? []).flatMap(n => n.pages ?? []),
  ])].sort((a, b) => a - b);
  function copyText(q) {
    const r = get(q);
    if (!r) return '';
    const blocks = ['Source review: ' + (REVIEW_LABELS[r.status] ?? r.status)];
    const added=addedAnswer(q);
    if(added)blocks.push('Answer added by the assistant from the uploaded notes (not an original bank key):\n'+(added.question?'Clarified/suggested question: '+added.question+'\n':'')+added.text+'\nPDF pages: '+added.pages.join(', '));
    if (r.completion) blocks.push('Suggested completion (not the recovered original wording):\n' + r.completion.question + '\nAnswer: ' + r.completion.answer + '\nWhy this completion: ' + r.completion.reason);
    if (r.answer && grade(q) === null) blocks.push('Reviewed answer/limitation: ' + r.answer);
    if (r.representativeId !== q.id) blocks.push('Any option letters quoted in the discussion refer to the reviewed bank version #' + r.representativeId + '; use this version\'s mapped answer above.');
    for (const n of r.notes ?? []) {
      blocks.push(n.text + (n.pages?.length ? '\nUploaded PDF pages: ' + n.pages.join(', ') : ''));
      for (const ref of n.external ?? []) blocks.push(ref.label + ': ' + ref.url);
    }
    for (const c of concepts(q)) blocks.push(c.title + '\n' + c.paragraphs.join('\n\n') + '\nUploaded PDF pages: ' + c.pages.join(', '));
    if (pages(q).length) blocks.push('Source: ' + data.source.title + ' · ' + data.source.filename + '\nPDF page numbers: ' + pages(q).join(', ') + ' (not the lecture-local footer).');
    return blocks.join('\n\n');
  }
  return {get, grade, originalChoice, practiceGrade, concepts, pages, copyText, addedAnswer, hasOriginalAnswer, source: data?.source ?? null};
}
