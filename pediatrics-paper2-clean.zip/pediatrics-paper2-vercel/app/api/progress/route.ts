import { progress } from "../../../lib/study-api";
export const dynamic="force-dynamic";
export const GET=progress;
export const POST=progress;
