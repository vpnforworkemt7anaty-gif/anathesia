import { account } from "../../../lib/study-api";
export const dynamic="force-dynamic";
export const GET=account;
export const POST=account;
export const DELETE=account;
