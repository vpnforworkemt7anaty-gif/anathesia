import type { Metadata } from 'next';
export const metadata:Metadata={title:'Pediatrics · Paper 2',description:'Your Paper 2 study bank by branch, lecture and original source.'};
export default function RootLayout({children}:{children:React.ReactNode}){return <html lang="en"><body>{children}</body></html>}
