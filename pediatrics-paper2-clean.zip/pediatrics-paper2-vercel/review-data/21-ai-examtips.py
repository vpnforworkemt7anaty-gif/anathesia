"""Supplementary explanations for the checked AI / ExamTips import.

All C pages refer to the 384-page Complete Notes, never the MCQ PDF.
Original bank keys remain a separate, immutable layer.
"""
from pathlib import Path
import json

C('ai-birth-injuries', [], 'The tissue plane explains the birth-injury findings', [17,18],
  'A cephalhaematoma lies under the periosteum, so sutures limit its spread. Caput is superficial oedema and can cross sutures. Breakdown of collected blood can increase bilirubin; the presence of a scalp swelling does not itself identify its tissue plane.',
  'An upper brachial-plexus injury involving C5–C6 gives the characteristic Erb posture and an asymmetric/absent Moro response on the affected side. A clavicle or humeral fracture can also reduce movement through pain, so examine the limb rather than assigning every weak arm to nerve damage.')
C('ai-maturity-details', [], 'Maturity is assessed from several physical signs', [22,23,24],
  'The term measurements taught here are approximately 50 cm length, 35 cm head circumference and 33 cm chest circumference. Breast tissue, ear cartilage, skin/sole creases and genital development contribute to the physical assessment; one measurement alone is not a gestational-age score.',
  'In the course, a breast nodule becomes apparent around 33 weeks and is larger at term. An unusually pigmented scrotum or ambiguous genitalia prompts an endocrine/anatomical assessment; the lecture discusses congenital adrenal hyperplasia, ultrasound and karyotype in that context.')
C('ai-prematurity-details', [], 'Immature organs explain the complications of prematurity', [25,26],
  'Fragile cerebral vessels predispose to intraventricular haemorrhage, immature lungs to surfactant deficiency, and a large surface-area-to-mass ratio plus immature control to heat loss. These are different consequences of immaturity, rather than interchangeable names for respiratory distress.',
  'The notes also connect oxygen exposure with retinopathy risk and repeated blood sampling with anaemia. Cerebral palsy, hearing loss and visual impairment are possible long-term outcomes. The course eye-screening statement is discussed in this risk context, not as a universal newborn schedule.')
C('ai-neonatal-support', [], 'Respiratory support follows the infant’s physiological need', [18,74],
  'The lecture describes oxygen, CPAP and mechanical ventilation as progressively greater support, with high-frequency ventilation in selected severe disease. CPAP maintains distending pressure in a spontaneously breathing infant; a ventilator also supports ventilation when that is inadequate.',
  'Choose the support from breathing, oxygenation and the underlying illness. These names are not an automatic sequence that every neonate must pass through. Temperature, circulation and treatment of the cause remain part of stabilisation.')
C('ai-bpd', [], 'BPD is chronic lung morbidity after neonatal respiratory disease', [35],
  'The Complete Notes list bronchopulmonary dysplasia/chronic lung disease among the complications associated with severe neonatal respiratory disease and its treatment. This differs from an acute air leak or the initial surfactant-deficiency presentation.',
  'The MCQ bank supplies the oxygen-for-28-days wording. That numerical definition is not independently stated in the linked Complete Notes page, so it is retained as the bank’s key with an explicit verification limit rather than presented as a quotation from these notes.')
C('ai-rds-support', [], 'Support gas exchange while treating surfactant deficiency', [36,37],
  'The source combines oxygen/CPAP or ventilation with endotracheal surfactant when indicated. Surfactant addresses the high surface tension and alveolar collapse of RDS; pressure support and oxygen address the resulting impaired gas exchange.',
  'Temperature, feeding/fluids and assessment for infection are also listed. Numerical fluid or bicarbonate statements in these MCQs reproduce the lecturer’s outline; they require the infant’s clinical and laboratory context and are not a complete universal treatment protocol.')
C('ai-neonatal-polycythaemia', [], 'Increased red-cell mass raises viscosity and bilirubin load', [52,53],
  'The course uses a haematocrit above 65% for neonatal polycythaemia. Placental insufficiency/IUGR, an infant of a diabetic mother and twin-to-twin transfusion are teaching associations. More red cells can mean hyperviscosity and more bilirubin when those cells break down.',
  'The notes describe partial exchange using normal saline in selected affected infants. This is different from replacing blood to treat severe bilirubin toxicity. Beckwith–Wiedemann syndrome is associated with a large infant and omphalocele in the course’s differential.')
C('ai-g6pd', [], 'An enzyme defect causes non-immune haemolysis', [53,54],
  'G6PD deficiency causes oxidative red-cell injury rather than antibody-mediated haemolysis. A negative direct Coombs test therefore fits the mechanism; a normal-looking smear does not establish that the enzyme is normal.',
  'Treat the consequence being asked about: phototherapy for significant unconjugated jaundice and transfusion for important anaemia are different interventions. Avoid oxidative triggers. The lecture permits breastfeeding while discussing maternal exposure/diet precautions; do not infer that every jaundiced infant must stop feeding.')
C('ai-jaundice-assessment', [], 'Visible colour and measured bilirubin answer different questions', [49,50,58,217,218],
  'The neonatal source explicitly updates its visible-jaundice teaching value from 5 to about 7 mg/dL; the later hepatology chapter gives roughly 2–3 mg/dL beyond the neonatal setting. The age/context explains why these course numbers should not be treated as one interchangeable cutoff.',
  'Visibility is not a phototherapy or exchange threshold. Measure bilirubin and interpret age in hours, gestation and risk. Yellow skin with spared sclerae suggests a pigment such as carotene rather than bilirubin, as discussed in the hepatology examination section.')
C('ai-torch-overview', [], 'Congenital infections share findings but have distinguishing clues', [18,76,79,83],
  'Growth restriction, hepatosplenomegaly, jaundice and thrombocytopenia can occur in congenital infection and are not specific to one organism. The timing of maternal infection and the infant’s eye, ear, heart and neurological findings refine the differential.',
  'The course contrasts diffuse intracranial calcification in toxoplasmosis with the periventricular pattern of CMV, and cataract/deafness/cardiac disease in rubella. Do not assign every calcification or every neonatal infection to HSV merely because it belongs to a TORCH differential.')
C('ai-sepsis-obstetric', [], 'Maternal and delivery history modify early-onset infection risk', [70,71],
  'The notes link early-onset disease particularly with GBS and Gram-negative organisms, with E. coli important in preterm infants. Colonisation, prolonged membrane rupture and maternal infection alter risk before the infant develops obvious signs.',
  'The source’s intrapartum-antibiotic timing and Triple I/chorioamnionitis discussion explain prevention and risk assessment. Maternal fever is a signal to interpret with the other criteria; it is not by itself proof of the organism or of culture-positive neonatal sepsis.')
C('ai-sepsis-treatment', [], 'Empirical cover changes with timing, site and microbiology', [74,75,81],
  'The lecture’s early-onset regimen is ampicillin plus gentamicin; its meningitis/renal-impairment discussion includes cefotaxime. Late-onset choices add resistant Gram-positive cover such as vancomycin/teicoplanin according to setting. These differences reflect likely organisms and drug penetration/toxicity.',
  'Reassess a stable infant with negative cultures rather than treating every suspected infection for one fixed duration. The source gives different courses for bacteraemia, Gram-negative meningitis and bone/joint disease. Its examples explain the MCQ keys; culture results and the actual site remain essential.')
C('ai-syphilis-varicella', [], 'Distinguish early congenital infection from later sequelae', [78,79],
  'Early congenital syphilis can produce snuffles, a palm/sole rash and bone disease. Hutchinson teeth, interstitial keratitis and deafness belong to the later classic teaching pattern; exchanging early and late manifestations changes the answer.',
  'Congenital varicella in the source is linked to maternal infection around 8–20 weeks, with scarring and limb hypoplasia. Perinatal/neonatal varicella is a separate timing problem and should not be assumed to have the same malformation pattern.')
C('ai-perinatal-hbv', [], 'Combine active and passive protection after HBV exposure', [83,207,208],
  'For a newborn of an HBsAg-positive mother, the course gives hepatitis B vaccine plus HBIG promptly, within 12 hours, at different injection sites. The vaccine develops active immunity; HBIG provides immediate passive antibody.',
  'HBsAg indicates current surface-antigen positivity, whereas anti-HBs indicates immunity. Core antibody is evidence of exposure to infection rather than the response to a surface-antigen vaccine alone. These marker distinctions explain both prevention and serology questions.')
C('ai-chd-foundations', [], 'Embryology, oxygenation and examination frame the cardiac differential', [93,94,95],
  'The source places major structural cardiac development around weeks 3–8 and gives an approximate CHD incidence of 0.8%. Most cases are not explained by one identified cause; a syndrome association is a clue rather than a complete explanation for every lesion.',
  'Normally the right heart receives relatively desaturated venous blood and the left receives oxygenated pulmonary venous blood. A shunt, obstruction or parallel circulation changes that pathway. Down syndrome warrants the source’s echocardiographic assessment even if no murmur is heard.')
C('ai-murmur-grading', [], 'Describe timing and haemodynamics as well as loudness', [94,95],
  'A murmur is characterised by its timing, site, radiation, quality and intensity. A thrill is a palpable vibration associated with substantial turbulence. The lecture’s 5/6 phrasing is preserved in the supplied answer; the attached external clarification explains the conventional grade-4 threshold.',
  'A loud murmur is not a direct measurement of shunt volume or heart-failure severity. Its interpretation requires the age, lesion and other findings. Broad lecturer shorthand about all murmurs in infancy should be read with that qualification.')
C('ai-cardiac-palliation', [], 'Each palliative operation changes a particular flow pathway', [150,151,152,153,154,155],
  'Rashkind septostomy improves interatrial mixing. A Blalock–Taussig-type systemic-to-pulmonary shunt supplies lung flow. Glenn directs superior caval blood to the pulmonary artery; Fontan completes a selected single-ventricle venous pathway. These procedures solve different physiological limitations.',
  'Pulmonary artery banding deliberately reduces excessive pulmonary flow/pressure, unlike a shunt that increases lung blood supply. Norwood is part of staged palliation for hypoplastic left-heart physiology. A palliative procedure is not synonymous with anatomical total correction.')
C('ai-hf-details', [], 'Failure reflects load, myocardial function and compensatory responses', [139,142,143,144,145],
  'Pressure/volume overload, myocardial disease and arrhythmias can all cause failure. Neurohormonal responses help maintain perfusion initially but can increase congestion and workload. Increased wall tension also increases oxygen demand, explaining why the underlying physiology matters.',
  'The course uses EF below 50% or fractional shortening below 25% as systolic-function clues, but discusses hypertrophic/diastolic failure as an exception to simple cardiomegaly rules. Its modified Ross table places prolonged infant feeds/growth failure in Class IV; the classification wording must remain explicit rather than mixing tables.')
C('ai-rheumatic-context', [], 'Recognise the streptococcal setting and specific manifestations', [161,162,163,171,172],
  'Rheumatic fever follows an immune response to group A streptococcal pharyngitis; the joint or cardiac disease is not simply direct bacterial invasion. The source’s population risk categories affect how Jones criteria are applied.',
  'Erythema marginatum is an uncommon, non-itchy rash with pale centres that typically spares the face. Subcutaneous nodules occur over extensor/bony sites and are associated with cardiac involvement. Epidemiological numbers in the questions are course figures, not current surveillance estimates.')
C('ai-rheumatic-carditis', [], 'Acute inflammation and chronic valve damage have different effects', [168,169],
  'Rheumatic carditis can involve all cardiac layers, but valvar injury determines much of the lasting morbidity. Acute mitral/aortic regurgitation differs from chronic stenotic disease that develops after scarring.',
  'The Carey Coombs murmur is a mid-diastolic flow/inflammatory finding in acute mitral involvement, rather than proof of established chronic anatomical mitral stenosis. Aschoff bodies belong to the pathological description of rheumatic inflammation.')
C('ai-hepatitis-details', [], 'Transmission and the stage of illness organise hepatitis questions', [203,204,205,208,209],
  'HAV and HEV are enterically transmitted; HBV/HCV have different exposure pathways. The source places important HAV infectivity in the incubation period and early jaundice phase. EBV can produce hepatitis in the context of infectious mononucleosis.',
  'Aminotransferases reflect hepatocyte injury, while albumin can remain preserved early in an acute illness. The notes give a 2–4-day preicteric phase, which conflicts with the AI item’s 2–4-week option; the original option/key is retained and the discrepancy is marked.')
C('ai-hepatitis-vaccines', [], 'Vaccination and immunoglobulin serve different prevention roles', [207,208],
  'The course describes inactivated HAV vaccine from one year of age as two doses separated by about six months. HBV prevention uses its own vaccine schedule, with HBIG added for the specified exposure situations.',
  'An immunoglobulin supplies passive protection; it does not replace completing active vaccination. The MCQs preserve the lecturer’s schedule/context. A locally updated vaccination programme is a separate question from identifying the mechanism tested here.')
C('ai-liver-nutrition', [], 'Maintain nutrition while accounting for encephalopathy and cholestasis', [210,234],
  'The lecturer explicitly rejects withholding protein from every child with liver disease: inadequate intake promotes breakdown of the child’s own tissue. The source limits protein in its encephalopathy discussion and resumes it as the child improves.',
  'Medium-chain triglycerides enter the portal route and are useful when bile-dependent fat absorption is impaired. This explains the nutrition answer in cholestasis/ascites without implying that every dietary fat behaves identically.')
C('ai-alf-definition', [], 'PALF requires acute injury with significant vitamin-K-unresponsive coagulopathy', [210,211,212],
  'The course defines PALF in a child without prior chronic liver disease using acute biochemical injury plus coagulopathy not corrected by vitamin K: INR at least 1.5 with encephalopathy, or the source’s severe INR-above-2 pathway without requiring encephalopathy.',
  'Loss of hepatic synthesis explains the coagulopathy; factor VIII and vWF can rise. A prolonged INR does not mean every child is actively bleeding, so the source does not recommend routine plasma correction in the absence of bleeding or an invasive procedure. Encephalopathy and serial changes help assess severity.')
C('ai-alf-support', [], 'Acute liver failure threatens glucose control, brain function and circulation', [214,215],
  'Hypoglycaemia can reflect impaired hepatic glucose production and reduced insulin clearance. The neurological assessment is serial because worsening behaviour/consciousness or intracranial-pressure signs can indicate cerebral oedema.',
  'The source discusses careful fluid/glucose monitoring and mannitol or hypertonic saline for cerebral oedema in specialist care. A quoted maintenance-fluid percentage is a lecture framework, not a substitute for assessing perfusion, sodium, urine output and the individual child.')
C('ai-choledochal-cyst', [], 'A dilated extrahepatic bile duct can cause obstructive jaundice', [221,222],
  'The classic teaching combination is abdominal pain, jaundice and a right-upper-quadrant mass, with imaging showing cystic bile-duct dilatation. The anatomical dilatation distinguishes a choledochal cyst from failure of bile-duct patency in biliary atresia.',
  'The source describes excision with Roux-en-Y hepaticojejunostomy. This removes the abnormal segment and restores biliary drainage; it is a different operation from a Kasai procedure.')
C('ai-ascites', [], 'Ascitic-fluid characteristics help identify the mechanism', [229,230,231,232,233,234],
  'An elevated serum–ascites albumin gradient (about 1.1 g/dL or higher in the course) points toward portal-pressure mechanisms such as portal hypertension or cardiac congestion. A low-gradient process such as nephrotic-related low oncotic pressure has a different mechanism. Milky, triglyceride-rich fluid suggests chylous ascites.',
  'The notes distinguish treatment of the underlying disease, sodium/diuretic management, drainage for selected tense ascites and treatment of spontaneous bacterial peritonitis. These are separate clinical decisions; an association such as E. coli or spironolactone answers a specific question rather than every cause of abdominal fluid.')
C('ai-proteinuria-types', [], 'Amount, persistence and associated findings distinguish proteinuria patterns', [240,241,242,243,244,245],
  'A 24-hour collection discards the initial void and then includes urine through the next day’s end point. A spot protein/creatinine ratio offers another assessment. Fever-related transient proteinuria should not be confused with persistent nephrotic-range loss.',
  'Tubular protein loss is usually lower and relatively fixed; glomerular loss can be larger and vary with disease activity. Blood pressure, haematuria and renal function therefore help interpret the number. Orthostatic assessment compares samples collected in the relevant posture/time context.')
C('ai-ns-treatment-details', [], 'Treat the nephrotic process and assess its complications separately', [254,255,256],
  'Prednisolone is the source’s cornerstone for typical childhood steroid-sensitive nephrotic syndrome. Response to the initial course helps classify the disease; resistance or atypical features changes the need for investigation/biopsy and subsequent therapy.',
  'The course recommends an average protein intake with sodium management, rather than a high-protein cure for urinary loss. Albumin plus a diuretic is a selected severe-oedema measure, requiring attention to circulating volume. Drug doses and immunosuppression monitoring belong to the stated treatment context.')
C('ai-haematuria-workup', [], 'Confirm red cells before classifying red urine', [262,263,264],
  'The notes define microscopic haematuria using more than five RBCs per high-power field in the specified fresh sample. A dipstick reacting to haem pigment is not proof of intact urinary red cells; medicines, pigments and sample contamination can also make urine appear red.',
  'The teaching visibility estimate is about 1 mL of blood per litre of urine, so the denominator matters. History, microscopy, blood pressure, ultrasound and a urine calcium/creatinine ratio address different possible causes rather than being interchangeable confirmation tests.')
C('ai-recurrent-haematuria', [], 'The timing and basement-membrane findings distinguish recurrent disorders', [269,270],
  'IgA disease, Alport syndrome and thin-basement-membrane disease can all present with recurrent haematuria. Hearing/family findings and renal progression matter; haematuria alone does not establish the inherited diagnosis.',
  'The course contrasts the irregular basket-weave basement membrane of Alport with more uniform thinning. Although its thin-membrane description is usually benign, persistent proteinuria, hypertension or an adverse family course requires attention rather than an automatic reassurance from the label.')
C('ai-uti-details', [], 'Age and organism change the UTI presentation', [282,283,287,288,289,290],
  'E. coli predominates, while the source links Proteus with alkaline urine and stones. Neonates may present with systemic illness or jaundice rather than classic dysuria or fever; a haematogenous route is possible in that age group.',
  'Adenoviral haemorrhagic cystitis and asymptomatic bacteriuria are different from febrile bacterial upper UTI. The source describes a short self-limited viral course and generally no antibiotic treatment for asymptomatic bacteriuria. Confirm the relevant syndrome and a properly collected culture before applying a bacterial-treatment rule.')
C('ai-obstructive-uropathy', [], 'Locate the obstruction and assess its upstream effects', [299,300],
  'UPJ obstruction affects drainage from the renal pelvis into the ureter. Posterior urethral valves occur in boys and can cause a poor stream, a distended bladder and upstream dilatation; the source includes bladder catheter decompression in initial management.',
  'Severe fetal obstruction can reduce amniotic fluid and impair lung development. A ureterocele is a cystic dilatation of the terminal ureter, not a synonym for every hydronephrotic kidney.')
C('ai-pkd-treatment', [], 'Imaging and management depend on the question being asked', [312,313],
  'The source names ultrasound as a first-line structural assessment, with CT/MRI for further definition in the appropriate setting. A scan used to assess cortical scars is not identical to a functional GFR study merely because both use radionuclides.',
  'Management addresses hypertension, renal failure and associated liver disease rather than removing cysts as a universal cure. The lecture discusses dialysis, including peritoneal dialysis in small infants, and selected renal or combined liver–kidney transplantation.')
C('ai-genitourinary-details', [], 'Developmental anomalies, torsion and tumours require different reasoning', [314,315,318,319],
  'The course gives testicular descent in early infancy and orchiopexy around 9–15 months for persistent cryptorchidism. Fertility and malignancy risks explain follow-up; an undescended testis is an anatomical diagnosis, not by itself proof of every disorder of sexual development.',
  'A painless, non-transilluminating mass suggests a solid lesion and prompts imaging/markers such as AFP or hCG as appropriate. The source’s overall malignancy percentage lacks a precise age group; prepubertal and postpubertal tumour patterns must not be treated as one universal distribution.')
C('ai-secondary-immunodeficiency', [], 'An acquired illness or treatment can impair an initially formed immune system', [329,330,331],
  'HIV targets CD4 T-cell function. Malnutrition, malignancy, chronic kidney disease and immunosuppressive treatment are other acquired contexts in the source. Their presence distinguishes a secondary cause from an inherited defect; opportunistic infection alone does not identify which one.',
  'Immune dysregulation can also produce autoimmune disease. Screening quantity and screening function answer different questions, so a normal cell count does not establish every immune pathway as normal.')
C('ai-jia-details', [], 'Joint inflammation can alter both movement and growth', [345,346,347,348,349],
  'Arthritis requires objective inflammation such as swelling or restricted painful movement; arthralgia is pain without that same finding. The source links persistent immune activation and osteoclast activity with cartilage/bone damage.',
  'Count individual affected joints, including separate small joints, when applying the course subtype definitions. Chronic inflammation near a growth plate can initially lengthen an affected limb through increased growth. JIA remains a diagnosis requiring exclusion of alternatives, especially an acute infected joint.')
C('ai-vasculitis-context', [], 'Inflamed vessel walls can cause ischaemia or loss of wall integrity', [371,372],
  'Wall inflammation may narrow/occlude the lumen and reduce tissue perfusion, or weaken the wall and produce aneurysmal change. The organ pattern depends on the size and distribution of vessels involved.',
  'Fever, weight loss and raised inflammatory markers are not specific to vasculitis. Exclude infection and malignancy in the appropriate setting. The lecture’s childhood vessel-size framework and classification criteria organise patterns; they are not a diagnosis from one nonspecific symptom.')

ROOT=Path(__file__).resolve().parents[1]
bank=json.loads((ROOT/'public/questions.json').read_text())
meta=json.loads((ROOT/'public/bank-meta.json').read_text())
roots={i:g[0] for g in meta['duplicateGroups'] for i in g}
mapping=json.loads((ROOT/'import-data/ai-examtips-reviews.json').read_text())
seen=set()
for q in bank:
    if q.get('importId')!='ai-examtips':continue
    root=roots.get(q['id'],q['id'])
    if root<=1924:continue  # An exact alias inherits its existing medical review.
    item=mapping[f"{q['aiBookLectureNumber']}:{q['upstreamQuestionLabel']}"]
    A([root],*item['concepts'])
    # Identical aliases may contribute an additional contextual note once.
    for note in item['notes']:
        identity=(root,note['text'])
        if identity not in seen:
            N([root],note['text'],pages=note.get('pages'),external=note.get('external'))
            seen.add(identity)
    if item['status']!='supported':N([root],None,status=item['status'])
