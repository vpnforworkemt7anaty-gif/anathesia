-- Dedicated application database. No study questions or credentials are public.
CREATE TABLE IF NOT EXISTS profiles (
 name text PRIMARY KEY CHECK (name IN ('MO','Basant','Mada')),
 password_hash text NOT NULL,
 salt text NOT NULL,
 created_at bigint NOT NULL,
 failed_attempts integer NOT NULL DEFAULT 0,
 blocked_until bigint NOT NULL DEFAULT 0
);
CREATE TABLE IF NOT EXISTS sessions (
 token_hash text PRIMARY KEY,
 profile text NOT NULL REFERENCES profiles(name),
 expires_at bigint NOT NULL
);
CREATE INDEX IF NOT EXISTS sessions_expires_at_idx ON sessions(expires_at);
CREATE TABLE IF NOT EXISTS progress (
 profile text PRIMARY KEY REFERENCES profiles(name),
 events text NOT NULL DEFAULT '{}',
 revision integer NOT NULL DEFAULT 0,
 resume text
);
