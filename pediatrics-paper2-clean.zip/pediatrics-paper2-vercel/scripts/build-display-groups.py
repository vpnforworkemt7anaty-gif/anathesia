"""Compile manually checked display duplicates while retaining review identities."""
from pathlib import Path
import hashlib,json,re

ROOT=Path(__file__).resolve().parents[1]
bank=(ROOT/'public/questions.json').read_bytes()
questions=json.loads(bank)
decisions=json.loads((ROOT/'import-data/display-duplicates.json').read_text())
assert hashlib.sha256(bank).hexdigest()==decisions['bankSHA256'],'Review duplicate decisions after a bank change'
meta=json.loads((ROOT/'public/bank-meta.json').read_text())
parents={q['id']:q['id'] for q in questions}
def root(i):
    while parents[i]!=i:
        parents[i]=parents[parents[i]]
        i=parents[i]
    return i
def join(ids):
    assert all(i in parents for i in ids),ids
    target=min(root(i) for i in ids)
    for i in ids:parents[root(i)]=target
for group in meta['duplicateGroups']:join(group)
original_unique=len({root(i) for i in parents})
for pair in decisions['pairs']:join(pair['ids'])
sets={}
for i in parents:sets.setdefault(root(i),[]).append(i)
groups=[sorted(ids) for ids in sets.values() if len(ids)>1]
groups.sort(key=lambda ids:ids[0])
meta['reviewCanonicalQuestions']=original_unique
meta['uniqueQuestions']=len(sets)
meta['displayDuplicateGroups']=groups
(ROOT/'public/bank-meta.json').write_text(json.dumps(meta,ensure_ascii=False,separators=(',',':'))+'\n')
html_path=ROOT/'public/study.html'
html=html_path.read_text()
block='const DISPLAY_DUPLICATE_GROUPS='+json.dumps(groups,separators=(',',':'))+';'
if 'const DISPLAY_DUPLICATE_GROUPS=' in html:
    html=re.sub(r'const DISPLAY_DUPLICATE_GROUPS=\[.*?\];',lambda _:block,html,count=1)
else:
    old='const reviewRootQuestion=rootQuestion;'
    assert old in html
    html=html.replace(old,"const reviewDuplicateRoot=new Map(duplicateRoot);\nconst reviewRootQuestion=id=>reviewDuplicateRoot.get(Number(id))||Number(id);\n"+block+"\nduplicateRoot.clear();duplicateMembers.clear();\nfor(const group of DISPLAY_DUPLICATE_GROUPS){duplicateMembers.set(group[0],group);for(const id of group)duplicateRoot.set(id,group[0])}")
html=re.sub(r'[\d,]+ (?:reviewed|unique) questions ·',f"{len(sets):,} unique questions ·",html)
html_path.write_text(html)
report={'originalReviewIdentities':original_unique,'uniqueDisplayedQuestions':len(sets),'additionalDuplicatesRemoved':original_unique-len(sets),'allQuestionOccurrencesRetained':len(questions),'checkedPairs':len(decisions['pairs']),'groups':groups}
(ROOT/'outputs/deduplication-audit.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({k:v for k,v in report.items() if k!='groups'}))
