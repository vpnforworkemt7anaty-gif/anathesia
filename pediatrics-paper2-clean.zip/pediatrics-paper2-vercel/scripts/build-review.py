"""Build the reviewed notes layer without altering any original question record."""
from pathlib import Path
import hashlib,json,re,runpy

ROOT=Path(__file__).resolve().parents[1]
questions=json.loads((ROOT/'public/questions.json').read_text())
html=(ROOT/'public/study.html').read_text()
groups=json.loads(re.search(r'const DUPLICATE_GROUPS=(\[.*?\]);',html).group(1))
root_of={i:g[0] for g in groups for i in g}
valid_roots={root_of.get(q['id'],q['id']) for q in questions}
concepts={};reviews={}

def ids(value):
    if not isinstance(value,str):return list(value)
    result=[]
    for item in value.replace(',',' ').split():
        a,sep,b=item.partition('-')
        result.extend(range(int(a),int(b)+1) if sep else [int(a)])
    return result

def entry(number):
    assert number in valid_roots,('Unknown canonical question',number)
    return reviews.setdefault(str(number),{'status':'supported','concepts':[],'notes':[]})

def C(key,targets,title,pages,*paragraphs):
    assert key not in concepts,key
    assert paragraphs and all(1<=p<=384 for p in pages),key
    concepts[key]={'title':title,'pages':pages,'paragraphs':list(paragraphs)}
    for number in ids(targets):entry(number)['concepts'].append(key)

def N(targets,text,status=None,answer=None,correct=None,completion=None,pages=None,external=None):
    for number in ids(targets):
        item=entry(number)
        if text:item['notes'].append({'text':text,**({'pages':pages} if pages else {}),**({'external':external} if external else {})})
        if status:item['status']=status
        if answer is not None:item['answer']=answer
        if correct is not None:item['correctIndex']=correct
        if completion is not None:item['completion']=completion

def G(targets,text,pages=None):N(targets,text,status='source-gap',pages=pages)

def A(targets,*keys):
    """Attach an already authored explanation to a new, distinct question."""
    for key in keys:
        assert key in concepts,key
        for number in ids(targets):
            item=entry(number)
            if key not in item['concepts']:item['concepts'].append(key)

for path in sorted((ROOT/'review-data').glob('*.py')):
    runpy.run_path(str(path),init_globals={'C':C,'N':N,'G':G,'A':A})

def rank(q):
    return (20 if q.get('doc') else 0)+(13 if q.get('seq') else 0)+(6 if q.get('answerImage') else 0)-(4 if q.get('extra') else 0)-(8 if q.get('ai') else 0)-(7 if q.get('unverified') else 0)+(3 if q.get('type')=='MCQ' else 0)+(2 if 'Adrenaline HTML' in q.get('sourcesNormalized',[]) else 0)
representatives={}
def has_original(q):
    text=str(q.get('docAnswer') or q.get('e') or '').strip()
    idx=q.get('a')
    return (isinstance(idx,int) and 0<=idx<len(q.get('o',[]))) or bool(text and not re.fullmatch(r'not provided(?: in (?:the )?source)?\.?|no (?:source )?answer(?: was)? (?:provided|available).*|\[missing\]|gm%',text,re.I))
for q in questions:
    key=root_of.get(q['id'],q['id'])
    if key not in representatives or rank(q)>rank(representatives[key]):representatives[key]=q
for root,item in reviews.items():
    representative=representatives[int(root)]
    item['representativeId']=representative['id']
    if item.get('status') in ('conflict','completed') and 'correctIndex' in item:
        idx=item['correctIndex']
        assert representative.get('type')=='MCQ' and not representative.get('doc') and not representative.get('seq'),('Correction targets non-MCQ',root)
        assert 0<=idx<len(representative.get('o',[])),('Bad corrected index',root)
        item['correctOption']=representative['o'][idx]
missing_answer_roots={root_of.get(q['id'],q['id']) for q in questions if not has_original(q)}
for root in sorted(missing_answer_roots):
    item=reviews[str(root)]
    completion=item.get('completion')
    text=(completion or {}).get('answer') or item.get('answer') or item.get('correctOption')
    if not text:
        representative=representatives[root]
        if has_original(representative):text=representative.get('docAnswer') or representative.get('e')
    assert text,('Missing source-based answer/completion',root)
    pages=sorted({page for key in item['concepts'] for page in concepts[key]['pages']}|{page for note in item['notes'] for page in note.get('pages',[])})
    assert pages,('Added answer lacks uploaded-source page reference',root)
    item['addedAnswer']={'text':text,'pages':pages,'author':'assistant','basis':'uploaded-notes','notOriginalBankKey':True,**({'question':completion['question'],'reason':completion['reason']} if completion else {})}
result={'version':1,'source':{'title':'Pediatrics Paper 2 - Complete Notes','filename':'PEDIATRICS_PAPER_2_Complete_Notes_Compressed 2.pdf','pages':384,'pageNumbering':'PDF page, not the lecture-local page'},'concepts':concepts,'reviews':reviews}
missing=sorted(valid_roots-{int(k) for k in reviews})
stats={'canonicalQuestions':len(valid_roots),'reviewed':len(reviews),'unreviewed':len(missing),'concepts':len(concepts),'statuses':{s:sum(v['status']==s for v in reviews.values()) for s in sorted({v['status'] for v in reviews.values()})},'originalQuestionsSHA256':hashlib.sha256((ROOT/'public/questions.json').read_bytes()).hexdigest()}
result['coverage']=stats
(ROOT/'public/review-notes.json').write_text(json.dumps(result,ensure_ascii=False,separators=(',',':'))+'\n')
(ROOT/'outputs/review-coverage.json').write_text(json.dumps({**stats,'unreviewedIds':missing},indent=2)+'\n')
print(json.dumps(stats))

