"""Append the checked two-part bank; retain every source occurrence and old ID.

Regeneration: import-bank40.py, curate-ai-review.py, import-ai-examtips.py,
build-review.py, build-display-groups.py. No clinical key is inferred by this script.
"""
from pathlib import Path
import hashlib,json,re,unicodedata

ROOT=Path(__file__).resolve().parents[1]
compact=lambda x:json.dumps(x,ensure_ascii=False,separators=(',',':'))
manifest=json.loads((ROOT/'import-data/ai-examtips-bank.json').read_text())
reviews=json.loads((ROOT/'import-data/ai-examtips-reviews.json').read_text())
bank_path=ROOT/'public/questions.json'
questions=json.loads(bank_path.read_text())
previous_hash=hashlib.sha256(bank_path.read_bytes()).hexdigest()
old=questions[:manifest['originalCount']]
assert hashlib.sha256((compact(old)+'\n').encode()).hexdigest()==manifest['originalBankSHA256'],'Original 1,924 records changed'
meta_path=ROOT/'public/bank-meta.json';meta=json.loads(meta_path.read_text())
groups=[[i for i in g if i<=len(old)] for g in meta['duplicateGroups']]
groups=[g for g in groups if len(g)>1]
lectures={l['number']:l['title'] for l in manifest['lectures']}
branch_of={lecture:branch for branch,items in meta['branches'].items() for lecture in items}
fixed={1:'APGAR score',2:'Respiratory distress',3:'Jaundice',4:'Sepsis',7:'Rheumatic heart disease',8:'Bronchial asthma',10:'Nephrotic syndrome',11:'Hematuria and GN',12:'UTI',13:'Polycystic Kidney disease',14:'Immunodeficiency'}
def lecture_for(item):
    number=item['lectureNumber'];keys=reviews[f"{number}:{item['label']}"]['concepts']
    if number in fixed:return fixed[number]
    if number==5:
        return 'Cyanotic congenital heart disease' if any(k.startswith(('tof-','tga-','tapvr','right-sided-','truncus','cyanosis-','cyanotic-')) for k in keys) else 'Acyanotic congenital heart disease'
    if number==6:
        if item['label'] in ['45','46','47','48','49','E33']:return 'Cyanotic congenital heart disease'
        return 'Congestive heart failure' if any(k.startswith(('hf-','ai-hf','digoxin')) for k in keys) else 'Acyanotic congenital heart disease'
    if number==9:
        return 'Pediatric Acute liver failure' if any(k.startswith(('ai-alf','bank40-paracetamol','reye','bank40-hrs')) for k in keys) else 'Pediatric liver disease'
    if number==15:return 'SLE' if any(k.startswith(('sle-','lupus')) for k in keys) else 'JIA'
    if number==16:return 'Kawasaki disease' if any(k.startswith(('kd-','bank40-kawasaki')) for k in keys) else 'Vasculitis'
    raise AssertionError(number)
added=[]
for item in manifest['questions']:
    lecture=lecture_for(item);number=item['lectureNumber'];source=item['source']
    q={k:item[k] for k in ['id','q','o','a']}
    assert len(q['o'])==4 and all(q['o']) and 0<=q['a']<4
    assert item['originalAnswer']==f"{'ABCD'[q['a']]}. {q['o'][q['a']]}"
    q.update({'branch':branch_of[lecture],'lecture':lecture,'num':item['label'],
        'type':'MCQ','file':'ai-examtips','page':item['sourcePdfPage'],
        'letters':list('ABCD'),'tags':[source],'flags':[],
        'e':item['originalAnswer'],'key':{'text':item['originalAnswer'],'pages':[item['keyPdfPage']]},
        'sourcesNormalized':[source],
        'source':[f"{source} · {lectures[number]} · Q{item['label']} · AI / ExamTips MCQ PDF p. {item['sourcePdfPage']}",
                  f"Answer key · {source} · {lectures[number]} · Q{item['label']} · AI / ExamTips MCQ PDF p. {item['keyPdfPage']}"],
        'aiBookLectureNumber':number,'aiBookLecture':lectures[number],
        'upstreamQuestionLabel':item['label'],'aiPdfPage':item['sourcePdfPage'],
        'aiKeyPdfPage':item['keyPdfPage'],'f':False,'w':False,'unverified':False,
        'ai':source=='AI MCQ Bank','importId':'ai-examtips'})
    added.append(q)
assert [q['id'] for q in added]==list(range(1925,3207))
if len(questions)>len(old):
    existing=questions[len(old):]
    assert len(existing)==len(added),'Existing AI import length differs'
    for actual,expected in zip(existing,added):
        assert {k:v for k,v in actual.items() if k not in ['branch','lecture']}=={k:v for k,v in expected.items() if k not in ['branch','lecture']},'Existing source transcription/key differs'
questions=old+added

# Exact full stem + ordered options + answer text only. Numerical values,
# negation, case details and option-reference meaning are never discarded.
def norm(text):
    return re.sub(r'\s+',' ',unicodedata.normalize('NFKC',text).replace('’',"'").replace('‘',"'").replace('“','"').replace('”','"')).strip().casefold()
def signature(q):
    if q.get('type')!='MCQ' or q.get('doc') or q.get('seq'):return None
    a=q.get('a');options=q.get('o',[])
    if not isinstance(a,int) or not 0<=a<len(options):return None
    return (q['branch'],q['lecture'],norm(q['q']),tuple(map(norm,options)),norm(options[a]))
root_of={i:g[0] for g in groups for i in g}
by_signature={}
for q in old:
    sig=signature(q)
    if sig is not None:by_signature.setdefault(sig,q['id'])
exact=[]
for q in added:
    sig=signature(q);target=by_signature.get(sig)
    if target is not None:
        root=root_of.get(target,target)
        group=next((g for g in groups if g[0]==root),None)
        if group is None:group=[root];groups.append(group)
        group.append(q['id']);root_of[q['id']]=root
        exact.append({'ids':[target,q['id']],'reason':'Exact full question, ordered options and supplied answer after typography/whitespace normalisation.'})
    else:by_signature[sig]=q['id']
groups.sort(key=lambda g:g[0])
bank_bytes=(compact(questions)+'\n').encode();bank_path.write_bytes(bank_bytes)
meta['duplicateGroups']=groups;meta['totalInstances']=len(questions)
meta['reviewCanonicalQuestions']=len({root_of.get(q['id'],q['id']) for q in questions})
for source in ['AI MCQ Bank','ExamTips · Doctor Q','ExamTips · Exam Tip','ExamTips · Questions Bank']:
    if source not in meta['sourceOrder']:meta['sourceOrder'].append(source)
meta['imports']={**meta.get('imports',{}),'ai-examtips':{'instances':1282,'ai':775,'examTips':507,'lectures':16,'sourceSHA256':manifest['sourceSHA256']}}
meta_path.write_text(compact(meta)+'\n')
html_path=ROOT/'public/study.html';html=html_path.read_text()
for name,value in [('DUPLICATE_GROUPS',groups),('SOURCE_ORDER',meta['sourceOrder'])]:
    html,count=re.subn(r'const '+name+r'=\[.*?\];',lambda _:'const '+name+'='+compact(value)+';',html,count=1)
    assert count==1,name
html_path.write_text(html)
decisions_path=ROOT/'import-data/display-duplicates.json';decisions=json.loads(decisions_path.read_text())
new_hash=hashlib.sha256(bank_bytes).hexdigest()
assert decisions['bankSHA256'] in [manifest['originalBankSHA256'],previous_hash,new_hash],'Review unknown bank change before updating display decisions'
decisions['bankSHA256']=new_hash
decisions_path.write_text(json.dumps(decisions,ensure_ascii=False,indent=2)+'\n')
report_path=ROOT/'outputs/ai-examtips-validation.json'
report=json.loads(report_path.read_text()) if report_path.exists() else {}
report.update({'imported':len(added),'AI':775,'ExamTips':507,'lectures':16,'originalRecordsUnchanged':True,'originalKeysPreserved':True,'exactDuplicateAliases':exact,'sourceSHA256':manifest['sourceSHA256'],'bankSHA256':new_hash})
report_path.write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({'imported':len(added),'totalInstances':len(questions),'reviewCanonicalQuestions':meta['reviewCanonicalQuestions'],'exactAliases':len(exact)}))
