"""Append the checked Bank 40 transcription without changing existing question IDs.

The import manifest preserves section provenance, PDF keys, and the deliberate
duplicate decisions. Re-running validates the same import rather than adding it twice.
"""
from pathlib import Path
import hashlib
import json
import re

ROOT = Path(__file__).resolve().parents[1]
manifest = json.loads((ROOT / 'import-data/question-bank40.json').read_text())
bank_path = ROOT / 'public/questions.json'
questions = json.loads(bank_path.read_text())
old = questions[:manifest['originalCount']]
compact = lambda obj: json.dumps(obj, ensure_ascii=False, separators=(',', ':'))
assert hashlib.sha256(compact(old).encode()).hexdigest() == manifest['originalRecordsSHA256'], 'Existing question records changed'
meta_path = ROOT / 'public/bank-meta.json'
meta = json.loads(meta_path.read_text())
groups = [g[:] for g in meta['duplicateGroups']]
root_of = {i: g[0] for g in groups for i in g}
by_id = {q['id']: q for q in old}
added = []
for item in manifest['questions']:
    section = item['section']
    key_pages = ', '.join(map(str, item['keyPages']))
    q = {key: item[key] for key in ['id', 'branch', 'lecture', 'num', 'q', 'o', 'a', 'type', 'sourcePdfPage']}
    q.update({
        'page': item['sourcePdfPage'], 'file': 'bank40',
        'letters': list('ABCD'[:len(item['o'])]),
        'tags': [section], 'flags': [], 'e': item['originalAnswer'],
        'key': {'text': item['originalAnswer'], 'pages': item['keyPages']},
        'source': [f"{section} · Question Bank 40 · PDF p. {item['sourcePdfPage']} · Q{item['num']}",
                   f"Answer key · {section} · Question Bank 40 · PDF p. {key_pages} · Q{item['num']}"],
        'sourcesNormalized': [section], 'f': False, 'unverified': False,
        'w': item['type'] != 'MCQ', 'importId': 'bank40',
    })
    if item.get('upstreamQuestionNumber'):
        q['upstreamQuestionNumber'] = item['upstreamQuestionNumber']
        q['source'].append(f"Original hepatology file Q{item['upstreamQuestionNumber']} · renumbered Q{item['num']} in Question Bank 40; original Q1–2 were not supplied")
    if item['duplicateOf']:
        target = item['duplicateOf']
        assert target in by_id and by_id[target]['lecture'] == item['lecture'], item['id']
        root = root_of.get(target, target)
        group = next((g for g in groups if g[0] == root), None)
        if group is None:
            group = [root]
            groups.append(group)
        if item['id'] not in group:
            group.append(item['id'])
    added.append(q)
if len(questions) > len(old):
    assert questions[len(old):len(old)+len(added)] == added, 'An existing import differs; review before replacing it'
else:
    bank_path.write_text(compact(old + added) + '\n')
questions = old + added + questions[len(old)+len(added):]
meta['duplicateGroups'] = groups
meta['totalInstances'] = len(questions)
root_of = {i: g[0] for g in groups for i in g}
meta['uniqueQuestions'] = len({root_of.get(q['id'], q['id']) for q in questions})
for item in manifest['questions']:
    if item['section'] not in meta['sourceOrder']:
        meta['sourceOrder'].insert(meta['sourceOrder'].index('Unspecified source') if 'Unspecified source' in meta['sourceOrder'] else len(meta['sourceOrder']), item['section'])
meta_path.write_text(compact(meta) + '\n')
html_path = ROOT / 'public/study.html'
html = html_path.read_text()
for name, value in [('DUPLICATE_GROUPS', groups), ('SOURCE_ORDER', meta['sourceOrder'])]:
    html, count = re.subn(r'const ' + name + r'=\[.*?\];', lambda _: 'const ' + name + '=' + compact(value) + ';', html, count=1)
    assert count == 1, name
html = re.sub(r'[\d,]+ reviewed questions ·', f"{meta['uniqueQuestions']:,} reviewed questions ·", html)
html_path.write_text(html)
print(json.dumps({'imported': len(added), 'newCanonical': 64, 'totalInstances': len(questions), 'uniqueQuestions': meta['uniqueQuestions']}))
