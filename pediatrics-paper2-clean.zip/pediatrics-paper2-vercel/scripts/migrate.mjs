import {readFile} from 'node:fs/promises';
import {neon} from '@neondatabase/serverless';
const url=process.env.DATABASE_URL||process.env.POSTGRES_URL;
if(!url)throw Error('Connect the project database before running the migration.');
const sql=neon(url),schema=await readFile(new URL('../db/schema.sql',import.meta.url),'utf8');
const statements=schema.split(';').map(s=>s.trim()).filter(Boolean);
await sql.transaction(statements.map(s=>sql.query(s)));
console.log('Study schema is ready. No study profiles or progress were changed.');
