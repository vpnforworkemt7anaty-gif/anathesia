from pathlib import Path
import fitz,re,json,hashlib,collections,argparse
parser=argparse.ArgumentParser(description="Extract and validate the supplied two-part AI / ExamTips PDF")
parser.add_argument("pdf",type=Path)
parser.add_argument("output",type=Path)
args=parser.parse_args()
src=args.pdf
out=args.output
out.mkdir(parents=True,exist_ok=True)
doc=fitz.open(src);questions=[];lectures={};current=None;lecture=None;mode='intro';pending=None

def finish():
 global current
 if current is None:return
 current['q']=' '.join(current.pop('_stem')).strip()
 current['o']=[' '.join(x).strip() for x in current.pop('_options')]
 assert current['q'] and len(current['o'])==4 and all(current['o']),current
 if current['label'].startswith('E'):assert current.get('source') in ['ExamTips · Exam Tip','ExamTips · Doctor Q','ExamTips · Questions Bank'],current
 else:current['source']='AI MCQ Bank'
 questions.append(current);current=None

for page_no,page in enumerate(doc,1):
 spans=[s for b in page.get_text('dict')['blocks'] if 'lines' in b for l in b['lines'] for s in l['spans'] if 59<=s['bbox'][1]<790]
 for s in spans:
  text=s['text'].strip();size=s['size'];bold='Bol' in s['font'];color=s['color']
  if not text:continue
  start=re.match(r'^Lecture (\d+) · (.*)',text)
  if start and size>18:
   finish();lecture=int(start[1]);lectures[lecture]={'number':lecture,'title':start[2],'startPage':page_no,'keys':{},'expectedAI':None,'expectedExamTips':0};mode='questions';pending=None;continue
  if lecture is None:continue
  if size>18 and not start:
   lectures[lecture]['title']+=' '+text;continue
  expected=re.search(r'(\d+) (AI MCQ Bank|ExamTips) questions',text)
  if expected and size<10:lectures[lecture]['expectedAI' if expected[2]=='AI MCQ Bank' else 'expectedExamTips']=int(expected[1]);continue
  if text=='Answer Key' and size>12:
   finish();mode='keys';continue
  if text.startswith('Part '):continue
  if mode=='keys':
   if re.fullmatch(r'E?\d+',text) and 7<=size<=8.5:pending=text;continue
   if pending and text in 'ABCD' and len(text)==1 and 9.6<size<10:
    assert pending not in lectures[lecture]['keys'],(lecture,pending,page_no)
    lectures[lecture]['keys'][pending]={'letter':text,'pdfPage':page_no};pending=None
   continue
  if mode!='questions':continue
  match=re.fullmatch(r'(E?\d+)\.',text)
  if match and bold and abs(size-9.6)<.05:
   finish();current={'lectureNumber':lecture,'label':match[1],'sourcePdfPage':page_no,'_stem':[],'_options':[]};continue
  if current is None:continue
  if text.startswith('ExamTips ·') and size<7.2:current['source']=text;continue
  if len(text)==1 and text in 'ABCD' and bold and abs(size-9.2)<.05 and color in [2054794,2061416]:
   assert text=='ABCD'[len(current['_options'])],(page_no,current,text)
   current['_options'].append([]);continue
  if current['_options'] and abs(size-9.2)<.05:
   current['_options'][-1].append(text);continue
  if not current['_options'] and abs(size-9.6)<.05:
   current['_stem'].append(text);continue
  if text not in ['■'] and color==2042163:raise ValueError((page_no,'Unhandled body text',text,size,current))
finish()
for q in questions:
 key=lectures[q['lectureNumber']]['keys'].get(q['label']);assert key,q
 q.update({'a':'ABCD'.index(key['letter']),'originalAnswer':key['letter']+'. '+q['o']['ABCD'.index(key['letter'])],'keyPdfPage':key['pdfPage']})
for number,lec in lectures.items():
 qs=[q for q in questions if q['lectureNumber']==number]
 ai=[q for q in qs if not q['label'].startswith('E')];tips=[q for q in qs if q['label'].startswith('E')]
 assert len(ai)==lec['expectedAI'] and len(tips)==lec['expectedExamTips'],(number,len(ai),len(tips),lec)
 assert [q['label'] for q in ai]==[str(i) for i in range(1,len(ai)+1)],number
 assert [q['label'] for q in tips]==['E'+str(i) for i in range(1,len(tips)+1)],number
 assert len(qs)==len(lec['keys']),(number,len(qs),len(lec['keys']))
assert len(questions)==1282 and sum(q['source']=='AI MCQ Bank' for q in questions)==775
result={'sourceFilename':src.name,'sourceSHA256':hashlib.sha256(src.read_bytes()).hexdigest(),'pdfPages':len(doc),'printedTotalPages':133,'lectures':list(lectures.values()),'questions':questions}
(out/'parsed-bank.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
for number,lec in lectures.items():
 qs=[q for q in questions if q['lectureNumber']==number]
 (out/f'lecture-{number:02d}.txt').write_text(lec['title']+'\n'+'\n'.join(q['label']+' | '+q['q']+' | '+q['originalAnswer'] for q in qs)+'\n')
print(json.dumps({'count':len(questions),'sources':dict(collections.Counter(q['source'] for q in questions)),'lectures':[{k:v for k,v in x.items() if k!='keys'} for x in lectures.values()]},ensure_ascii=False))
