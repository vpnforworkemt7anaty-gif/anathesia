import { neon, type NeonQueryFunction } from '@neondatabase/serverless';

// Keep the existing, parameterized study queries while changing the storage
// transport from a Worker binding to PostgreSQL over HTTPS.
export function postgresQuery(query:string){let index=0;return query.replace(/\?/g,()=>'$'+(++index));}
let client:NeonQueryFunction<false,false>|null=null;
function sql(){
 if(client)return client;
 const url=process.env.DATABASE_URL||process.env.POSTGRES_URL;
 if(!url)throw new Error('The study database has not been connected.');
 return client=neon(url);
}
type Result={meta:{changes:number}};
export type Statement={
 query:string;values:unknown[];
 bind(...values:unknown[]):Statement;
 first<T=Record<string,unknown>>():Promise<T|null>;
 run():Promise<Result>;
};
function statement(query:string,values:unknown[]=[]):Statement{
 return {
  query,values,
  bind(...parameters){return statement(query,parameters);},
  async first<T>(){const rows=await sql().query(postgresQuery(query),values);return (rows[0] as T|undefined)??null;},
  async run(){const result=await sql().query(postgresQuery(query),values,{fullResults:true});return {meta:{changes:result.rowCount??0}};}
 };
}
const database={
 prepare:statement,
 async batch(statements:Statement[]){
  const connection=sql();
  const results=await connection.transaction(statements.map(s=>connection.query(postgresQuery(s.query),s.values)),{fullResults:true});
  return results.map(r=>({meta:{changes:r.rowCount??0}}));
 }
};
export function getDb(){return database;}
