import { getDb } from "./database";
const NAMES=["MO","Basant","Mada"] as const;
const COOKIE="ped2_session";
const MAX_AGE=60*60*24*30;
import {validateEvents,validateResume,legacyResume,realEvents,withLegacyResume,mergeProgress,newer,type StudyEvent,type ResumeEvent} from "./progress-model";
export {validateEvents,mergeProgress} from "./progress-model";
function db(){return getDb();}
const json=(body:unknown,status=200,headers:Record<string,string>={})=>Response.json(body,{status,headers:{"Cache-Control":"no-store",...headers}});
function cookie(request:Request,value:string,age=MAX_AGE){const secure=!['terminal.local','localhost','127.0.0.1'].includes(new URL(request.url).hostname);return `${COOKIE}=${value}; Path=/; HttpOnly; SameSite=Lax; Max-Age=${age}${secure?'; Secure':''}`;}
function sameOrigin(r:Request){const origin=r.headers.get('origin');return (!origin||origin===new URL(r.url).origin)&&r.headers.get('sec-fetch-site')!=='cross-site';}
async function body(r:Request,max:number){if(Number(r.headers.get('content-length')||0)>max)throw new Error('Request too large');const text=await r.text();if(text.length>max)throw new Error('Request too large');const data=JSON.parse(text);if(!data||typeof data!=='object'||Array.isArray(data))throw new Error('Invalid request');return data;}
function hex(bytes:ArrayBuffer){return Array.from(new Uint8Array(bytes),b=>b.toString(16).padStart(2,'0')).join('');}
async function digest(s:string){return hex(await crypto.subtle.digest('SHA-256',new TextEncoder().encode(s)));}
async function passwordHash(password:string,salt:string){const key=await crypto.subtle.importKey('raw',new TextEncoder().encode(password),'PBKDF2',false,['deriveBits']);return hex(await crypto.subtle.deriveBits({name:'PBKDF2',hash:'SHA-256',salt:new TextEncoder().encode(salt),iterations:100000},key,256));}
function equal(a:string,b:string){let diff=a.length^b.length;for(let i=0;i<Math.max(a.length,b.length);i++)diff|=(a.charCodeAt(i)||0)^(b.charCodeAt(i)||0);return diff===0;}
async function session(r:Request){const token=r.headers.get('cookie')?.split(';').map(s=>s.trim()).find(s=>s.startsWith(COOKIE+'='))?.slice(COOKIE.length+1);if(!token||!/^[a-f0-9]{64}$/.test(token))return null;const tokenHash=await digest(token);return db().prepare('SELECT profile, token_hash FROM sessions WHERE token_hash = ? AND expires_at > ?').bind(tokenHash,Date.now()).first<{profile:string;token_hash:string}>();}
export async function account(r:Request):Promise<Response>{
 try{
  if(r.method==='GET'){const s=await session(r);return json({user:s?{name:s.profile}:null,profiles:NAMES});}
  if(!sameOrigin(r))return json({error:'Invalid request origin'},403);
  if(r.method==='DELETE'){const s=await session(r);if(s)await db().prepare('DELETE FROM sessions WHERE token_hash = ?').bind(s.token_hash).run();return json({ok:true},200,{'Set-Cookie':cookie(r,'',0)});}
  const data=await body(r,1024);const name=NAMES.find(n=>n.toLowerCase()===String(data.name||'').toLowerCase());
  if(!name)return json({error:'Choose MO, Basant or Mada.'},400);
  const password=data.password;if(typeof password!=='string'||password.length<6||password.length>128)return json({error:'Use a passcode between 6 and 128 characters.'},400);
  type Profile={name:string;password_hash:string;salt:string;failed_attempts:number;blocked_until:number};
  let row=await db().prepare('SELECT * FROM profiles WHERE name = ?').bind(name).first<Profile>();
  if(row?.blocked_until&&row.blocked_until>Date.now())return json({error:'Too many attempts. Try again in a few minutes.'},429);
  if(!row){const salt=hex(crypto.getRandomValues(new Uint8Array(16)).buffer);const hash=await passwordHash(password,salt);await db().prepare('INSERT INTO profiles(name,password_hash,salt,created_at) VALUES (?,?,?,?) ON CONFLICT (name) DO NOTHING').bind(name,hash,salt,Date.now()).run();row=await db().prepare('SELECT * FROM profiles WHERE name = ?').bind(name).first<Profile>();}
  if(!row||!equal(await passwordHash(password,row.salt),row.password_hash)){
   const attempts=(row?.failed_attempts||0)+1;await db().prepare('UPDATE profiles SET failed_attempts = ?, blocked_until = ? WHERE name = ?').bind(attempts,attempts>=10?Date.now()+300000:0,name).run();return json({error:'Incorrect passcode for this profile.'},401);
  }
  const token=hex(crypto.getRandomValues(new Uint8Array(32)).buffer);const tokenHash=await digest(token);
  await db().batch([
   db().prepare('UPDATE profiles SET failed_attempts = 0, blocked_until = 0 WHERE name = ?').bind(name),
   db().prepare('INSERT INTO progress(profile,events,revision) VALUES (?,\'{}\',0) ON CONFLICT (profile) DO NOTHING').bind(name),
   db().prepare('DELETE FROM sessions WHERE expires_at <= ?').bind(Date.now()),
   db().prepare('INSERT INTO sessions(token_hash,profile,expires_at) VALUES (?,?,?)').bind(tokenHash,name,Date.now()+MAX_AGE*1000)
  ]);
  return json({user:{name}},200,{'Set-Cookie':cookie(r,token)});
 }catch{return json({error:'Could not complete sign-in. Please try again.'},500);}
}
export async function progress(r:Request):Promise<Response>{
 try{
  const user=await session(r);if(!user)return json({error:'Sign in to your study profile.'},401);
  const expected=r.headers.get('x-study-profile');if(expected&&expected!==user.profile)return json({error:'The active study profile changed. Sign in again.'},401);
  const v2=new URL(r.url).searchParams.get('v')==='2';
  type Row={events:string;revision:number;resume:string|null};
  if(r.method==='GET'){
   const row=await db().prepare('SELECT events,revision,resume FROM progress WHERE profile = ?').bind(user.profile).first<Row>();
   const etag=`"ped2-${user.profile}-${row?.revision||0}"`;
   if(v2&&r.headers.get('if-none-match')===etag)return new Response(null,{status:304,headers:{ETag:etag,'Cache-Control':'no-store'}});
   const stored:Record<string,StudyEvent>=row?JSON.parse(row.events):{};
   const resume=row?.resume?JSON.parse(row.resume):legacyResume(stored),events=realEvents(stored);
   return json(v2?{events,resume,revision:row?.revision||0}:{events:withLegacyResume(events,resume)},200,{ETag:etag});
  }
  if(!sameOrigin(r))return json({error:'Invalid request origin'},403);
  let incoming:Record<string,StudyEvent>,incomingResume:ResumeEvent|null=null,protocol2=false;
  try{
   const data=await body(r,2_000_000);protocol2=data.protocol===2;
   if(protocol2&&new TextEncoder().encode(JSON.stringify(data)).length>32768)throw Error('Batch too large');
   incoming=validateEvents(data.events, !protocol2);
   if(protocol2){if(data.resume!==undefined)incomingResume=validateResume(data.resume);}
   else{incomingResume=legacyResume(incoming);incoming=realEvents(incoming);}
  }catch{return json({error:'Invalid progress data'},400);}
  // CAS merges deltas from concurrent devices; unchanged batches never write.
  for(let retry=0;retry<5;retry++){
   const row=await db().prepare('SELECT events,revision,resume FROM progress WHERE profile = ?').bind(user.profile).first<Row>();if(!row)throw Error('Profile missing');
   const stored:Record<string,StudyEvent>=JSON.parse(row.events),existing=realEvents(stored);
   const oldResume:ResumeEvent|null=row.resume?JSON.parse(row.resume):legacyResume(stored);
   const {merged,changed}=mergeProgress(existing,incoming);
   const resume=incomingResume&&newer(incomingResume,oldResume)?incomingResume:oldResume;
   const needsWrite=changed||resume!==oldResume||Object.keys(stored).length!==Object.keys(existing).length;
   const ack=()=>protocol2?{ok:true,events:Object.fromEntries(Object.keys(incoming).map(k=>[k,merged[k]])),...(incomingResume?{resume}:{}),revision:row.revision+(needsWrite?1:0)}:{ok:true};
   if(!needsWrite)return json(ack());
   const result=await db().prepare('UPDATE progress SET events = ?, resume = ?, revision = revision + 1 WHERE profile = ? AND revision = ?').bind(JSON.stringify(merged),resume?JSON.stringify(resume):null,user.profile,row.revision).run();
   if(result.meta.changes===1)return json(ack());
  }
  return json({error:'A sync is already running. Your device will retry.'},409);
 }catch{return json({error:'Sync is temporarily unavailable. Your device keeps its local copy.'},500);}
}
