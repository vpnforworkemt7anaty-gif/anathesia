import bankMeta from '../public/bank-meta.json' with {type:'json'};
export const MAX_QUESTION_ID=bankMeta.totalInstances;
export type StudyEvent = {v:string|number|boolean|null;t:number;d:string};
export type ResumeValue = {config:Record<string,unknown>;cursors:Record<string,number>};
export type ResumeEvent = {v:ResumeValue;t:number;d:string};
export const newer = (a:{t:number;d:string},b?:{t:number;d:string}|null) => !b || a.t>b.t || (a.t===b.t && a.d>b.d);
const object = (v:unknown):v is Record<string,unknown> => !!v && typeof v==='object' && !Array.isArray(v);
function metadata(e:Record<string,unknown>){
 if(!Number.isSafeInteger(e.t)||Number(e.t)<0||Number(e.t)>Date.now()+300000||typeof e.d!=='string'||e.d.length>100)throw Error('Invalid event metadata');
}
export function validateEvents(input:unknown,legacy=false):Record<string,StudyEvent>{
 if(!object(input)||Object.keys(input).length>12000)throw Error('Invalid progress');
 const clean:Record<string,StudyEvent>=Object.create(null);
 for(const [key,e] of Object.entries(input)){
  const match=/^(pick|wrong|mark|revisionWrong|revisionMarked):(\d+)$/.exec(key);if(!match)throw Error('Invalid progress key');
  const id=Number(match[2]);if(!(id>=1&&id<=MAX_QUESTION_ID)&&!(legacy&&match[1]==='pick'&&id>=990000&&id<=990080))throw Error('Invalid question');
  if(!object(e))throw Error('Invalid event');metadata(e);
  const {v,t,d}=e;if(!(v===null||typeof v==='boolean'||(typeof v==='number'&&Number.isFinite(v))||(typeof v==='string'&&v.length<=100)))throw Error('Invalid value');
  clean[key]={v,t,d} as StudyEvent;
 }
 return clean;
}
export function validateResume(input:unknown):ResumeEvent{
 if(!object(input)||!object(input.v)||!object(input.v.config)||!object(input.v.cursors))throw Error('Invalid resume');metadata(input);
 const {config,cursors}=input.v;
 const strings=(v:unknown)=>Array.isArray(v)&&v.length<=64&&v.every(s=>typeof s==='string'&&s.length<=150);
 if(!strings(config.selected)||!strings(config.typeChoice))throw Error('Invalid filters');
 if(config.sources!==undefined&&(!object(config.sources)||Object.keys(config.sources).length>32||Object.values(config.sources).some(v=>!strings(v))))throw Error('Invalid sources');
 if(config.sourceFamilies!==undefined){
  const allowed=['nms','exams','formatives','lectures','collected','edits','ai','examtips','other'];
  if(config.sourceFamilies!==null&&(!strings(config.sourceFamilies)||(config.sourceFamilies as string[]).some(s=>!allowed.includes(s))))throw Error('Invalid global sources');
 }else if(config.sources===undefined)throw Error('Missing source filters');
 if(!['all','wrong','marked','unanswered'].includes(String(config.mode))||!['single','list'].includes(String(config.view)))throw Error('Invalid view');
 if(typeof config.search!=='string'||config.search.length>1000||!Number.isInteger(config.index)||Number(config.index)<0||Number(config.index)>MAX_QUESTION_ID)throw Error('Invalid cursor');
 if(typeof config.auto!=='boolean'||typeof config.review!=='boolean'||typeof config.hideDuplicates!=='boolean'||!Number.isFinite(config.delay)||Number(config.delay)<0||Number(config.delay)>30000)throw Error('Invalid settings');
 for(const value of [config.cursorId,config.unansweredPendingId])if(value!==null&&(!Number.isInteger(value)||Number(value)<1||Number(value)>MAX_QUESTION_ID))throw Error('Invalid question cursor');
 if(config.cursorOffset!==undefined&&(!Number.isFinite(config.cursorOffset)||Number(config.cursorOffset)<0||Number(config.cursorOffset)>1))throw Error('Invalid question offset');
 if(Object.keys(cursors).length>256||Object.entries(cursors).some(([k,v])=>!/^[a-z0-9]{1,16}$/.test(k)||!Number.isInteger(v)||Number(v)<1||Number(v)>MAX_QUESTION_ID))throw Error('Invalid saved cursors');
 // Retain compatibility with the trial's 80 x 80-character resume bundle.
 if(JSON.stringify({v:1,config,cursors}).length>6400)throw Error('Resume too large');
 return {v:{config,cursors:cursors as Record<string,number>},t:Number(input.t),d:String(input.d)};
}
export function legacyResume(events:Record<string,StudyEvent>):ResumeEvent|null{
 const head=events['pick:990000'];if(!head||!Number.isInteger(head.v)||Number(head.v)<1||Number(head.v)>80)return null;
 let raw='';for(let i=1;i<=Number(head.v);i++){const p=events[`pick:${990000+i}`];if(!p||typeof p.v!=='string'||p.t!==head.t||p.d!==head.d)return null;raw+=p.v;}
 try{const value=JSON.parse(raw);if(value.v!==1)return null;return validateResume({v:{config:value.config,cursors:value.cursors||{}},t:head.t,d:head.d});}catch{return null;}
}
export function realEvents(events:Record<string,StudyEvent>){return Object.fromEntries(Object.entries(events).filter(([k])=>!/^pick:9900\d\d$/.test(k)));}
export function withLegacyResume(events:Record<string,StudyEvent>,resume:ResumeEvent|null){
 const result={...events};if(!resume)return result;
 const raw=JSON.stringify({v:1,...resume.v}),parts=raw.match(/[\s\S]{1,80}/g)||[];
 result['pick:990000']={v:parts.length,t:resume.t,d:resume.d};parts.forEach((v,i)=>{result[`pick:${990001+i}`]={v,t:resume.t,d:resume.d};});return result;
}
export function mergeProgress(existing:Record<string,StudyEvent>,incoming:Record<string,StudyEvent>){const merged={...existing};let changed=false;for(const [k,e] of Object.entries(incoming))if(newer(e,merged[k])){merged[k]=e;changed=true;}return {merged,changed};}
