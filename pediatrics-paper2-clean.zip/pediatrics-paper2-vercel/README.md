# Pediatrics · Paper 2 · Vercel edition

All original sources and 3,206 question occurrences are preserved, with
2,491 distinct questions shown after reviewed duplicate consolidation. Study profiles remain MO,
Basant and Mada. There are no extra users or administrator roles.

This edition uses standard Next.js on Vercel and PostgreSQL through the Neon
serverless driver. It does not depend on a ChatGPT Site or a Cloudflare Worker.
The database connection is server-only. Existing password hashes and progress
can be imported without changing the users' passcodes. Old browser sessions
must sign in again because the website origin changes.

## Deployment

Production: https://pediatrics-paper2.vercel.app/study.html

The project `pediatrics-paper2` is deployed in the qqq Vercel Hobby team.
Neon database `neon-cordovan-ferry` is connected on the Free plan, with
server-only DATABASE_URL environment variables. The schema is installed and
the existing profile and progress have been imported. Sessions were not
copied: sign in on the new website with the existing profile passcode.

For updates, redeploy this same project. Its Vercel dashboard accepts updated
project files, or a repository / Vercel CLI can be connected later. After
environment changes, redeploy with the latest Project Settings. Do not create
a second project or database to update the existing deployment.

The current production deployment is `dpl_3s8iA4dFYr9BC3WGR6zA8svt8iNn` (Ready).
The Vercel Root Directory is `pediatrics-paper2-vercel`, matching the wrapper
folder in this archive and the uploaded file paths. Preserve that structure
for later dashboard uploads, or deliberately reconcile Root Directory before
deploying a flat source tree. Framework is Next.js and Node.js is 24.x.

All 2,601 review identities have a source-review record, with 206 teaching
concepts, focused explanations, actual PDF page references, corrections and
labelled recall reconstructions. Gaps, ambiguous wording and incomplete source
coverage are explicitly identified. Original bank content is preserved.
External guideline clarifications are separately named and linked. The full
384-page PDF is not published. Review data is static; explanations add no
per-question database calls.

For a separate installation, provision a dedicated free database, apply
`db/schema.sql`, and connect DATABASE_URL before deployment. Never include
private database exports or credentials in this source or browser assets.

## Low-usage synchronization

Answers save locally immediately. Only new timestamped changes and a separate
resume snapshot enter the durable outbox. The server acknowledges received
versions; newer edits remain queued. The client never polls while idle.
Normal writes are batched, debounce for 1.5 seconds and run at most once every
10 seconds. Each batch is at most 28,000 UTF-8 bytes. Retries back off and stop
after five automatic failures; offline changes stay on the device. Reopening
or reconnecting resumes sync. Conditional reads use ETags. Unchanged batches
do not update the PostgreSQL record.

## Local checks

`npm test`, `npm run typecheck`, and `npm run build`.

The sync tests cover offline/reload recovery, three profiles, concurrent
devices/tabs, ACK races, bounded retries and request size, legacy state,
storage failure, Retry-After and timeouts. The live production checks and
remaining verification limits are documented in `VERIFICATION.md`.

## Bank 40 content update (prepared 23 October 2026)

The source now contains 1,924 occurrences / 1,319 canonical questions. The
22-page Bank 40 import adds 95 occurrences: 92 MCQs and three written questions,
with 31 deliberately matched duplicates and 64 new canonical questions. Each
top-level section is its source label, even when a section spans several
lectures or branches. Bank-PDF page numbers and Complete Notes page numbers
are distinct. The original 1,829 records and their IDs are byte-identical.

`import-data/question-bank40.json` retains the checked transcription, official
keys, model answers, source pages, upstream hepatology numbering and duplicate
decisions. `python3 scripts/import-bank40.py` validates/repeats the import;
`python3 scripts/build-review.py` regenerates all 1,319 source reviews.

Attempts on reordered duplicate choices now retain the originating question
ID and map the selected option by text when another version is displayed.
Existing root-keyed attempts remain readable. A missing/rewritten alternative
retains completion without inventing a selected letter. The event schema and
sync request frequency do not change.

All 34 tests, TypeScript and the production build pass. This update has not
yet been deployed: Vercel MCP returns team-scope 403, the CLI API endpoint is
unavailable from this environment, and the dashboard update requires a folder
drop. The last confirmed live deployment remains
`dpl_XKJCNdFiHxr3Y7r4xp1d2nEG7cZe`. To publish, extract this archive and drop
the `pediatrics-paper2-vercel` folder on the existing project overview, then
choose **Deploy to Production**. Preserve the configured Root Directory:
`pediatrics-paper2-vercel`.

## Global sources and answer display revision

Sources now have one shared selector for all lectures, with six visible groups:
NMS, Exams 37–39, Formatives, Lectures & doctors, HAZEM / SHEHAB, and Final
edits. Every question retains its original section/source names and detailed
references. Saved global filters and all new bank IDs validate on the server;
older per-lecture resume formats remain readable.

An original answer is always the primary answer after reveal, including keys
that disagree with the notes. The clarification and reviewed alternative live
in an explanation disclosure that starts closed. Source-based answers added
by the assistant are explicitly labelled, with actual PDF pages. All 65
missing-answer occurrences (28 review identities) have a labelled answer or a
clearly distinguished teaching completion. Where the original stem is wholly
lost, the related replacement is expressly identified rather than presented
as a recovered original.

The manually checked display groups remove 69 more repetitions, leaving
1,250 unique displayed questions. All 1,924 original records, answer variants,
source references and 1,319 review identities stay intact. Clinically different
qualifiers, such as APGAR 3 versus 7, early versus late sepsis, PS versus AS,
and different EXCEPT options, are retained. Repeat visibility is always off.

Regenerate in this order after a checked import: `python3 scripts/import-bank40.py`,
`python3 scripts/build-review.py`, `python3 scripts/build-display-groups.py`.
The duplicate decision file is tied to the bank hash so a later content change
requires reviewing the grouping decisions. All 38 tests, TypeScript and the
production build pass. Publication still requires uploading this source folder
to the same Vercel project; no production database or account was changed.


## Final navigation and exact-source revision

The six global source groups are retained for selection. Every question now
shows the complete original source names above its stem (for example, Exam 39
or Formative 12 — Neonatology), including matching versions' named sources.
Bank 40 page provenance remains separate from the Complete Notes pages.

Full list now saves the question at the reading position and a relative offset
within that card, debounced and quantized. Reopening on another device restores
that question using its new rendered height and loads the required page of
cards even when it is beyond the first 200. It uses the same profile and bounded
resume outbox as One by one; no idle polling or new database tables are added.

Auto-next now follows graded choices in both views, including keyboard answers.
Opening an explanation pauses that pending advance; explanations still start
closed. Revealing a written/model answer leaves it available to read. Disabling
Auto-next cancels a pending timer.

Not answered yet uses an in-memory set for each profile. Answering, navigating,
filtering and later sync updates keep its questions present until page refresh.
The first cloud read establishes the starting progress without dropping answers
made while it was loading. Refresh builds a fresh unanswered set.

47 tests, TypeScript and the production build pass. Production publication was
verified on 24 October 2026: the existing project shows Ready, and the live page
shows complete original source names above the stem with the old pause control
removed. Deployment path: `/qqq-f4b7/pediatrics-paper2/22Jaqa7AZM1mLHJ1V2MVKZC3CkFu`.
The existing Root Directory remains `pediatrics-paper2-vercel`. Historical pending
publication notes above are superseded by this result. No extra upload is needed
for this release. No production account or progress was modified for verification.


## Source-key practice and visible conflict notice

A supplied MCQ answer is now retained for normal choice selection and answer
highlighting even when the review finds ambiguity, a conflict or a source gap.
The selected bank answer has an explicit Source answer label. Practice checks
choices against the supplied key; the independent reviewed answer/limitation
remains in the optional explanation and does not replace the bank key.

A warning appears above the question stem before answering. Original answers
remain in their normal answer area, with the explanation disclosure closed.
The screenshot's ARPKD question and both duplicate versions now allow selecting
and highlighting the supplied B, Liver cysts may be present. Their unresolved
medical review is preserved. Genuinely missing option keys are still completed
only when the existing source review supplies a uniquely mapped answer; no
original letter is fabricated. Manual Add to wrong-answer review stays available.

51 tests, TypeScript and production build pass. The audit covers all 1,756
supplied MCQ key occurrences, including 304 previously disabled occurrences and
26 occurrences with a different reviewed alternative. Questions/review JSON,
accounts and progress remain unchanged. This follow-up is published in production
as `dpl_G37HTz6u7p2buNUejh8vxfNAtdpp`, Ready on the existing domain. Team access
was successfully authorized; native Vercel deployment now works. The live module
version and source digests match the checked files. No further upload is needed.


## AI and ExamTips import — 25 October 2026

The supplied 130-page AI MCQ PDF contains 775 AI questions and 507 ExamTips
questions across 16 upstream lectures. Both parts are available as independent
global source groups, with Doctor Q, Exam Tip and Questions Bank preserved as
precise original source names. Each question retains its upstream lecture,
question label, physical PDF page, key page and original answer. The printed
133-page footer includes three unsupplied report/notes pages; all 1,282 listed
questions and their keys are present in the actual PDF.

All 1,924 pre-import records and IDs remain unchanged. New IDs are 1925–3206.
The 42 manually checked display-duplicate links remove 41 additional repeats;
variants and independent medical reviews remain available. Different ages,
numbers, early/late infection and different correct-answer contexts stay distinct.
Each new question has source-based teaching topics and optional explanations,
including focused notes for source conflicts, wording and coverage limits.
Original keys remain the practice answers even when flagged.

To reproduce from the checked manifests (no PDF or runtime secrets needed):

```bash
python scripts/import-bank40.py
python scripts/curate-ai-review.py
python scripts/import-ai-examtips.py
python scripts/build-review.py
python scripts/build-display-groups.py
npm test
npm run typecheck
npm run build
```

The optional extraction script takes the original PDF path and an output
directory; it requires PyMuPDF and validates all question counts, options and
keys. A second Poppler extraction independently matched all 1,282 key letters
and physical key pages. The source PDFs remain outside public hosting.

The import adds static data and two permitted resume-filter values. Existing
profiles, passcodes, answer IDs, sync batching and the free Neon database remain
in place. No per-question server operation, idle polling or paid service was added.

AI and ExamTips are published on the existing production URL. All 53 tests
pass. Live source digests match the checked HTML, bank, review data, metadata,
review module and resume validator. Both source counts (775 and 507) are
present in the loaded UI. No application console errors were observed. The
production sign-in dialog was respected and no saved study progress was changed.


## Focused study interface

Session filters, statistics, search and view settings now live in a closed
Controls dialog. A compact header button opens it on demand. Choosing lectures
continues through the existing source/lecture drawer. Opening controls pauses
Auto-next; its keyboard shortcuts do not answer hidden questions.

One by one uses the available viewport as a stable reading frame. The card
scrolls for long questions or explanations while Previous/Next remain in the
same bottom row. Changing questions resets the card directly without moving
the document. Answer reveals, bookmarks and incoming progress preserve the
current card's reading offset. Full list retains normal document scrolling
and the existing cross-device question/fraction resume.

Source names remain above the question; long precise page references wrap
on small screens. Redundant type/duplicate/supported badges are hidden in the
single-question frame; source warnings and original keys remain visible.
No bank, review, profile or database change is part of this interface update.
56 tests pass; TypeScript and optimized build pass. The actual static interface
was checked in the managed browser at 320×667, 390×844, 768×1024 and 1366×768,
including controls and Full list. See outputs/focus-ui-validation.json.

The focused interface is published as dpl_6fzQAKPc3o84443Q2PaAN9pg6vaN
on the existing production domain. All six checked runtime/source digests match
the verified source. Error/fatal runtime scan: no matching records.


## Space reveal and Auto-next — 28 October 2026

Space now reveals the current answer, then advances after the selected Auto-next
delay, including written/model answers. Directly clicking Reveal still leaves
time to read. A held Space key cannot reveal/skip successive questions. The
focused Reveal button uses the same shortcut without a duplicate native click.
Opening the optional explanation or Controls cancels the pending advance;
disabling Auto-next and existing profile/filter/visibility guards still apply.
59 tests pass; TypeScript and production build pass. Source questions, original
answers, medical reviews, accounts and database are unchanged.

Space Auto-next is published on the existing production URL as
`dpl_3s8iA4dFYr9BC3WGR6zA8svt8iNn`, READY. Six runtime/source digests match.
