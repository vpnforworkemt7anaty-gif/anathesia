# Vercel migration checks

Validated locally on 22 October 2026:

- Production Next.js build passed, including TypeScript.
- All 19 existing sync/model tests passed.
- All 52 public assets exactly match the previous deployed source: UI, source
  references, images and all 1,829 original question occurrences are unchanged.
- The two API routes use standard Next.js server functions and a server-only
  PostgreSQL adapter, with parameterized queries and atomic session batches.
- The schema restricts study profile names to MO, Basant and Mada.

Production deployment completed on 22 October 2026:

- Vercel production deployment `dpl_BjffUjQizEy4nXPibQFurAxnhxHN` is Ready.
- Public URL: https://pediatrics-paper2.vercel.app/study.html
- Vercel Hobby and Neon Free plans were visibly confirmed. No paid upgrade
  or payment details were used.
- Neon is connected to the existing Vercel project in Production and Preview.
  The project was redeployed after its environment variables were supplied.
- All four schema statements and both private import statements executed
  successfully. Counts verified: one existing profile and one progress row.
  Password hashes, salts, progress and resume were preserved; sessions were
  intentionally not migrated. No private export is included in this archive.
- Six live HTTP checks passed: profile discovery, actual PostgreSQL session
  lookup using a nonexistent test token, unauthenticated progress rejection,
  invalid-profile rejection, cross-origin rejection and byte-for-byte equality
  of the production question bank with the tested source.
- The production sign-in screen renders the three requested study profiles.

Verification limit: no user's passcode was entered or reset, and no production
profile was claimed for testing. Authenticated save/resume across two devices
has not been manually exercised on this new origin. The previously passing
sync/model tests cover its offline, concurrent-device and recovery behavior.


## Source review production verification

Deployment `dpl_XKJCNdFiHxr3Y7r4xp1d2nEG7cZe` is Ready on the existing production domain. The live review JSON matches the tested file exactly (all 1,255 reviews / 158 concepts); the live original bank matches its original SHA256 (1,829 records). Review filters, explanation pause, original source tags and three-profile sign-in render on the live page. No production account was created or changed and no passcode was entered. Authenticated answer reveal and cross-device sync were not exercised in this content-release verification. Full details and hashes are in `outputs/review-validation.json`.

## Bank 40 update — checked locally, awaiting publication

All 95 imported occurrences have their section as source, official answer/model
answer and question/key page provenance. They form 31 duplicate occurrences
and 64 new canonical questions. Total: 1,924 occurrences / 1,319 canonical
questions, with 1,319 substantive reviews and no unreviewed question.

The original 1,829 records serialize to exactly their original SHA256:
`5b3e5b34c5536d0b5250a27538536c91b51b1ed8c52e9c26891d137012defd15`.
The three written models are preserved. Ambiguous tumour-age, ARPKD,
criteria-version, PGE1/critical-PS and APGAR-timing questions remain ungraded;
the CHD pulmonary-flow item with two valid exceptions is explicitly flagged.
External clarifications have separate named links, while notes page references
use the actual 384-page PDF.

All 34 tests pass, including actual study renderer tests for written reveal,
section-source filtering, source-page labels, safe ambiguous grading and
cross-version answer mapping in both directions. All original sync tests
still pass. TypeScript and the production Next.js build pass.

No production database writes or account changes were made. Browser QA of the
new content is limited to the existing Node VM tests of the actual UI script;
the earlier local file preview was blocked and no bypass was attempted.
The live site still serves the previous release. Vercel team API scope remains
403 and the dashboard offers drag/drop with its file input disabled. The
prepared source folder must be dropped onto the existing project overview.

## Global-source, original-answer and duplicate-display revision

The current source shows 1,250 unique questions from 1,924 retained records.
It preserves 1,319 independent review identities so grouping repeated questions
does not replace one variant's key, review or saved progress with another.
The 79 manually checked duplicate links consolidate 69 additional questions.
Different clinical qualifiers remain separate; tests explicitly protect
APGAR 3/7, before/after delivery, PS/AS, increased/decreased flow, early/late
sepsis, RF/ANA, risk/EXCEPT and physiological/pathological comparisons.

All original answers are primary after reveal, including disputed keys.
Explanation disclosures start closed. All 65 missing-answer records across
28 review identities show an assistant-labelled addition with actual source
pages. Unrecoverable original wording is distinguished from a related teaching
replacement. The full questions JSON is unchanged, SHA256
`cf8994ad5cd5db5f20d2b58a17ccd3669b74f4d4b9fee58238a87ac3c4b08e26`.

38 tests pass, including a renderer audit of every record, six global source
families, cross-lecture source selection, full original-answer retention,
closed explanations, conservative attempt mapping and server validation of
new question IDs and global-source resume state. The 19 original sync tests
remain passing. TypeScript and the production build pass. The live site was
not updated; Vercel publication retains the previously documented blocker.


## Final navigation / exact source verification — 23 October 2026 UTC

Story: a learner answers from the three-profile study page, saves changes through
the existing bounded progress API, and resumes the same question/relative place
in Full list on a differently sized screen. Original sources appear above the
stem; the global picker remains grouped; explanations remain closed.

- All 47 tests passed. Actual study-script tests cover keyboard Auto-next,
  full-list scrolling past the 200-card boundary, disabling/cancelling the timer,
  opening an explanation, stable unanswered membership after multiple answers,
  navigation/filter/remote updates, refresh recalculation and profile isolation.
- The full-list renderer test captures a debounced anchor at index 250, validates
  its API resume envelope, restores it on a smaller screen with different card
  heights, and captures a final position on pagehide. Unchanged position does
  not create another resume write.
- The sync transport test exchanges Full list position in both device directions
  and observes zero further traffic during an hour of idle time. Server validation
  accepts relative offsets in [0,1], rejects malformed offsets, and still accepts
  previous saved formats.
- TypeScript and the optimized Next.js build passed. Review/answer data and the
  bank SHA256 are unchanged. No database migration or production data mutation.
- Browser inspection of the current production page confirms the 1,250-question
  release, global source selector and old pause control. The current dashboard
  shows Ready / Vercel Drop at deployment path
  `/qqq-f4b7/pediatrics-paper2/9fvJJb14oPcWAi5s9zSXbmSQ5Nd4`.
  This supersedes the earlier checkpoint's assertion that Bank 40/global sources
  were still unpublished; the new navigation code has not been uploaded.
- Publication remains blocked: native Vercel project inspection returns the
  team's missing-access 403 and its suggested team-authorization tools are absent.
  The signed-in project overview supports a manual project-folder drop. A previous
  CLI login succeeded in the browser but its API network route remains blocked;
  repeating authentication would not resolve that limit.

Verification limit: the new navigation script has local DOM/geometry/timer and
sync/model tests, not an authenticated two-device browser run against production.
The existing mandatory sign-in dialog was respected and no passcode was entered.
The earlier blocked file preview was not bypassed. Publish to the same existing
project, then verify the new source label and absence of the old pause control.


## Final production publication verified — 24 October 2026

The user uploaded the tested final folder to the existing project. The current
Production Deployment card is Ready at deployment path
`/qqq-f4b7/pediatrics-paper2/22Jaqa7AZM1mLHJ1V2MVKZC3CkFu` (Vercel Drop).
The unchanged public URL is https://pediatrics-paper2.vercel.app/study.html.

The live page renders 1,250 unique questions and the expected three-profile sign-in.
Its first question's exact sources include Exam 39 and Formative 12 — Neonatology,
with Bank 40 PDF p. 20. DOM order is source-top, source-inline, cardhead, confirming
that precise source names precede the question stem. The old pause-notes control
is absent. These markers confirm the final navigation/source revision has reached
production. No application console errors were observed (browser extension metadata
errors were outside the application). The supplied remote build log also confirms
compilation, TypeScript and static-page generation completed; the dashboard Ready
state confirms the later publication stage completed.

The prior team-access/CLI restriction did not prevent the user's manual upload.
No additional deployment, migration, sign-in or progress change was performed by
the agent. Authenticated two-device behavior remains covered by the 47 local UI,
model and sync tests rather than a live passcode-based browser run. No new code
was changed during this production check.


## Source-key visibility follow-up — 24 October 2026

The reported ARPKD item has a supplied B key but its ambiguous review caused the
UI to disable choices and omit normal answer highlighting. Practice grading now
uses the supplied key when present; the independent reviewed grade remains
conservative and may still be null or disagree. An explicit warning above the
stem and a Source answer label make that distinction visible.

51 tests pass. The screenshot regression confirms all four choices are enabled,
B stays highlighted after selection, the plain original B answer precedes the
closed explanation, and it is not falsely added to wrong-answer practice. Another
regression keeps original C highlighted when review suggests B. The complete bank
is audited for original-key preservation, including 304 previously disabled
occurrences. Missing original option keys do not acquire fabricated answers.
Prior navigation, sync, source grouping and original-record hash tests still pass.
TypeScript and optimized Next.js build pass. Both content JSON hashes match the
previous published files exactly. The review module import uses v=2 to avoid an
old cached module being paired with the new renderer.

This follow-up is not deployed yet. Vercel project inspection still gives the
team-scope 403; unlike earlier checkpoints, authorize_team_access is now exposed.
A team consent link can enable the existing connection for the intended team.
No production login, password, profile or progress was changed in this fix.
See outputs/source-key-visibility-validation.json.


## Source-key correction published — 25 October 2026

The user completed the native Vercel team consent. Same-connection project lookup
succeeded for the intended team/project. Deployment
`dpl_G37HTz6u7p2buNUejh8vxfNAtdpp` was created through the Vercel MCP with the
complete sanitized source manifest, the existing project ID, production target,
Next.js, Node 24.x and Root Directory pediatrics-paper2-vercel. Unchanged content
was reused by digest; only 188,550 bytes across nine changed/additional files
needed upload. No new project, database, migration, credentials or account was made.

The native deployment response is READY with no alias error and both existing
domains, including pediatrics-paper2.vercel.app. Source-tree digest verification
matches the checked study.html, review-layer.js, questions.json, review-notes.json
and progress-model.ts exactly. The public study page renders its bank and three
profiles, imports /review-layer.js?v=2, uses source-key practice grading and places
the conflict notice above the stem. No application console errors were observed.
The error/fatal runtime scan for this deployment returned no matching records in
the last 10 minutes.

The source-key screenshot scenario is covered by the 51 previously passing local
tests: original B selectable/highlighted, original text primary, warning above,
optional explanation closed, reviewed medical ambiguity retained. The mandatory
production sign-in dialog was respected; no passcode or saved attempt was used
for live verification. Runtime code is unchanged from the checked/deployed source.
This successful publication supersedes all prior source-key pending/access notes.


## AI / ExamTips import — current release

The strict PyMuPDF extraction found 1,282 complete four-option questions, with
775 AI and 507 ExamTips records across all 16 declared lecture sequences.
A separate Poppler text extraction matched every original key letter and its
physical PDF key page. Original AI versus ExamTips subtypes are retained.
The SHA-256 of the supplied PDF is recorded in the import manifest.

The original 1,924-record prefix has the unchanged published SHA-256; IDs are
append-only through 3206. Every one of the 2,601 medical review identities has
a substantive explanation, using 206 authored concepts and focused notes.
All source keys remain selectable and primary; explanations start closed.
Independent external clarifications are visibly separated and linked.

42 manually reviewed new display links remove 41 repeats, resulting in 2,491
unique displayed questions while retaining all 3,206 original occurrences.
Numerical, age, anatomical, early/late infection and differing-answer qualifiers
are explicitly preserved as separate questions. New grouping tests cover the
AI/ExamTips global filters, original subtypes and precise PDF provenance.
Existing tests cover full-list resume, stable unanswered sets, keyboard answers,
Auto-next, profile isolation and bounded sync without idle traffic.

TypeScript and the optimized production build pass. The updated test suite has
53 cases. Final production status and source digests are recorded below after
publishing to the existing Vercel project. No production login or saved progress
is used or changed for verification.


AI / ExamTips production publication succeeded as
`dpl_HRcriwp75SEvYdYQXnW5bdi6s4dc`, target production, READY, with both
existing aliases. The native API required all retained source files to be
re-uploaded; the final 116-file source upload and deployment succeeded.
The six runtime/source digests in outputs/ai-examtips-production.json match
exactly. The live header shows 2,491 unique questions, and the loaded global
source section contains AI 775 and ExamTips 507. Application console errors: 0;
two unrelated Chrome-extension metadata messages were excluded. No authenticated
production practice was performed; the mandatory profile sign-in was respected.
The deployment error/fatal log scan over the last ten minutes returned no records.
The final archive adds this publication receipt and documentation only; runtime
files remain byte-identical to the deployed, verified version.


## Focused study interface

56 tests pass. New regressions cover modal controls cancelling Auto-next and
blocking answer/navigation shortcuts, single-question navigation without any
window scroll, and preserving reading offsets through reveal/bookmark/remote
updates. The DOM harness now models replacement of rendered descendants, so
old navigation listeners cannot remain attached to a newly rendered button.
TypeScript and the production build pass. All three content JSON files retain
the hashes from the AI / ExamTips production release.

Browser QA uses the actual public study HTML, modules and data on the official
managed static preview, without a cloud API or production credentials. The
Next.js dev script is not compatible with the preview daemon's Vite flags, so
the buildless study surface is previewed directly without changing its code.
Responsive iframe viewports cover 320×667, 390×844, 768×1024 and 1366×768.
Every viewport has page width equal to viewport width and navigation within
its visible height. Controls open/close, Full list renders all 123 APGAR cards,
and next-question navigation retains page scroll zero. This verifies responsive
layout in a desktop browser, not physical-device Safari or a mobile keyboard.
No production progress or profile was used for interaction tests.


Focused UI publication: dpl_6fzQAKPc3o84443Q2PaAN9pg6vaN is READY on both
existing production aliases. The deployed HTML and unchanged bank, review data,
metadata, review module and resume validator match the checked SHA-1 digests.
The live page exposes the collapsed Study controls header button. The deployment
error/fatal scan over ten minutes found no matching records. No production
passcode, profile, answer or cursor was changed during browser verification.
The final source archive adds this receipt/documentation only; application files
remain identical to the verified deployment. See outputs/focus-ui-production.json.


## Space reveal and Auto-next — 28 October 2026

Space now reveals the current answer, then advances after the selected Auto-next
delay, including written/model answers. Directly clicking Reveal still leaves
time to read. A held Space key cannot reveal/skip successive questions. The
focused Reveal button uses the same shortcut without a duplicate native click.
Opening the optional explanation or Controls cancels the pending advance;
disabling Auto-next and existing profile/filter/visibility guards still apply.
59 tests pass; TypeScript and production build pass. Source questions, original
answers, medical reviews, accounts and database are unchanged.

Space Auto-next publication: dpl_3s8iA4dFYr9BC3WGR6zA8svt8iNn, production
READY on both existing aliases. Six runtime/source digests match the checked
release; error/fatal scan found no matching records. No production progress was
used for testing. Final archive adds publication documentation only.
